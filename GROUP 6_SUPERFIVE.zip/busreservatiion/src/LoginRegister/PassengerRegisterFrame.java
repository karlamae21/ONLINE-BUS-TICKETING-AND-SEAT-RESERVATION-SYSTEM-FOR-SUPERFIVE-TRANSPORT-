
package LoginRegister;

import LoginRegister.PassengerAdminAccount;
import Database.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
public class PassengerRegisterFrame extends javax.swing.JFrame {
    
    public PassengerRegisterFrame() {
          initComponents();
    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblFullname = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();
        lblPassword = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        txtFirstname = new javax.swing.JTextField();
        txtLastname = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtUsername = new javax.swing.JTextField();
        lblpassword = new javax.swing.JLabel();
        btnRegister = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblMessage = new javax.swing.JLabel();
        lblfullname = new javax.swing.JLabel();
        lblemail = new javax.swing.JLabel();
        lblusername = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        lblmessage = new javax.swing.JLabel();
        lbluser = new javax.swing.JLabel();
        lbl = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        btnShowPassword = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        lblPassword1 = new javax.swing.JLabel();
        lblPassword2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jTextField1.setText("jTextField1");

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel2.setBackground(new java.awt.Color(250, 248, 237));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setBackground(new java.awt.Color(30, 105, 75));
        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(30, 105, 75));
        lblTitle.setText("REGISTRATION");
        jPanel2.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 70, 267, -1));

        lblFullname.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblFullname.setText("First name");
        jPanel2.add(lblFullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 160, 85, 18));

        lblUsername.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblUsername.setText("Username");
        jPanel2.add(lblUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 300, 101, -1));

        lblPassword.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblPassword.setText("Password");
        jPanel2.add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 370, 101, -1));

        lblEmail.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblEmail.setText("Email");
        jPanel2.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, 85, 20));

        txtFirstname.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jPanel2.add(txtFirstname, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 190, 280, 30));

        txtLastname.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jPanel2.add(txtLastname, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 190, 300, 30));

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        txtEmail.addActionListener(this::txtEmailActionPerformed);
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 260, 620, 30));

        txtUsername.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        txtUsername.addActionListener(this::txtUsernameActionPerformed);
        jPanel2.add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 330, 620, 30));

        lblpassword.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        lblpassword.setText("(Use Strong Password at least 8 characters)");
        jPanel2.add(lblpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 430, -1, -1));

        btnRegister.setBackground(new java.awt.Color(30, 105, 75));
        btnRegister.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("REGISTER");
        btnRegister.addActionListener(this::btnRegisterActionPerformed);
        jPanel2.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 650, 110, -1));

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel2.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 650, 92, -1));
        jPanel2.add(lblMessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 724, 389, 16));

        lblfullname.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jPanel2.add(lblfullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(679, 571, 321, -1));

        lblemail.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jPanel2.add(lblemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(1054, 649, 224, -1));

        lblusername.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jPanel2.add(lblusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel1.setText("Last name");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 160, -1, -1));

        Email.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jPanel2.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(781, 198, 212, -1));

        username.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jPanel2.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(793, 375, 212, -1));

        label.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel2.add(label, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 600, 318, 11));

        lblmessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel2.add(lblmessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(1068, 120, 210, -1));

        lbluser.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel2.add(lbluser, new org.netbeans.lib.awtextra.AbsoluteConstraints(853, 407, 238, -1));

        lbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel2.add(lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(787, 255, 206, -1));

        txtPassword.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        txtPassword.addActionListener(this::txtPasswordActionPerformed);
        jPanel2.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 400, 530, 30));

        btnShowPassword.setBackground(new java.awt.Color(30, 105, 75));
        btnShowPassword.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnShowPassword.setForeground(new java.awt.Color(255, 255, 255));
        btnShowPassword.setText("SHOW");
        btnShowPassword.addActionListener(this::btnShowPasswordActionPerformed);
        jPanel2.add(btnShowPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 400, 80, 30));

        jComboBox2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. What is your mother's name?", "2. What is the name of your first pet?", "3. What is your favorite food?", "4. What is your favorite color?", "5. What is your favorite place?" }));
        jPanel2.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 480, 620, 30));

        lblPassword1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblPassword1.setText("Select a Security Questions");
        jPanel2.add(lblPassword1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 450, -1, -1));

        lblPassword2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblPassword2.setText("Security Answer");
        jPanel2.add(lblPassword2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 520, -1, -1));

        jTextField2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jPanel2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 550, 620, 30));

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 1570, 830);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new SuperFiveFrame().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
       String firstname = txtFirstname.getText();
        String lastname = txtLastname.getText();
        String email = txtEmail.getText();
        String Username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());
        String question = jComboBox2.getSelectedItem().toString();
        String answer = jTextField2.getText().trim();
       if (firstname.isEmpty() || lastname.isEmpty()
        || email.isEmpty() || Username.isEmpty()
        || password.isEmpty() || answer.isEmpty()) {

    label.setText("Please complete all fields.");

            label.setText("Please complete all fields.");

        } else if (!firstname.matches("[a-zA-Z ]+")) {

            label.setText("First name must contain letters only.");

        } else if (!lastname.matches("[a-zA-Z ]+")) {

            label.setText("Last name must contain letters only.");

        } else if (!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {

            label.setText("Please enter a valid email.");

        } else if (!Username.matches("[A-Za-z0-9]+")) {

            label.setText("Username must contain letters and numbers only.");

        } else if (!password.matches("^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$")) {

            label.setText("Password needs letters, numbers, and symbols.");

        } else {

            String error = Database.UserDB.registerUser(
            firstname + " " + lastname,
            email,
            Username,
            password,
            question,
            answer
    );

    if (error == null) {
        label.setText("Registration successful.");
        new SuperFiveFrame().setVisible(true);
        this.dispose();
    } else {
        label.setText(error);
    }
            }
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void btnShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowPasswordActionPerformed
        if (txtPassword.getEchoChar() == 0) {
            txtPassword.setEchoChar('*');
            btnShowPassword.setText("Show");
        } else {
            txtPassword.setEchoChar((char) 0);
            btnShowPassword.setText("Hide");
        }
    }//GEN-LAST:event_btnShowPasswordActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsernameActionPerformed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> new PassengerRegisterFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Email;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnShowPassword;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JLabel label;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFullname;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblPassword1;
    private javax.swing.JLabel lblPassword2;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JLabel lblemail;
    private javax.swing.JLabel lblfullname;
    private javax.swing.JLabel lblmessage;
    private javax.swing.JLabel lblpassword;
    private javax.swing.JLabel lbluser;
    private javax.swing.JLabel lblusername;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFirstname;
    private javax.swing.JTextField txtLastname;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
