package Passenger;


import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;
import java.util.ArrayList;

public class PaymentFrame extends javax.swing.JFrame {
    
     private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PaymentFrame.class.getName());
     
    String from;
    String to;
    String travelDate;
    String tripTime;
    String pickupTime;
    String tripCode;
    String busType;
    
    double grandTotal;
    int farePerSeat;
    int selectedSeatCount;
    int totalFare;    
    ArrayList<String> passengerNames =
            new ArrayList<>();
    
    ArrayList<Integer> seats =
            new ArrayList<>();

    ArrayList<String> firstNames = new ArrayList<>();
    ArrayList<String> lastNames = new ArrayList<>();
    String contactNumber = "";
    String email = "";

    public String paymentMethod;

    
  
public void loadPayment() {

    int linersFee = 20;
    int insurance = 20;
    int serviceFee = 50;

    selectedSeatCount = seats.size();
    totalFare = farePerSeat * selectedSeatCount;

    grandTotal = totalFare + linersFee + insurance + serviceFee;

    lblFarePerSeat.setText("₱" + farePerSeat);
    lblTotalFare.setText("₱" + totalFare);
    lblLinersFee.setText("₱" + linersFee);
    lblInsurance.setText("₱" + insurance);
    lblServiceFee.setText("₱" + serviceFee);
    lblNoPax.setText("" + selectedSeatCount);
    lblGrandTotal.setText("₱" + grandTotal);
    lblTotal.setText("₱" + grandTotal);
    lblTotalPayment.setText("₱" + grandTotal);
}

    public PaymentFrame() {
        initComponents();   
            setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

       pnlPassenger.setPreferredSize(new Dimension(479, 234));
        pack();
    }

  private void setFare() {

    if ((from.equals("CDO") && to.equals("Wao"))
            || (from.equals("Wao") && to.equals("CDO"))) {

        farePerSeat = 350;

    } else if ((from.equals("CDO") && to.equals("Dipolog"))
            || (from.equals("Dipolog") && to.equals("CDO"))) {

        farePerSeat = 550;

    } else if ((from.equals("CDO") && to.equals("Pagadian"))
            || (from.equals("Pagadian") && to.equals("CDO"))) {

        farePerSeat = 450;

    } else if ((from.equals("CDO") && to.equals("Maramag"))
            || (from.equals("Maramag") && to.equals("CDO"))) {

        farePerSeat = 300;

    } else if ((from.equals("CDO") && to.equals("Tubod"))
            || (from.equals("Tubod") && to.equals("CDO"))) {

        farePerSeat = 400;

    } else if ((from.equals("CDO") && to.equals("Kibawe"))
            || (from.equals("Kibawe") && to.equals("CDO"))) {

        farePerSeat = 350;

    } else if ((from.equals("CDO") && to.equals("Ozamiz"))
            || (from.equals("Ozamiz") && to.equals("CDO"))) {

        farePerSeat = 300;
    }
}

public void loadPaymentDetails() {

    int linerFee = 20;
    int insurance = 20;
    int serviceFee = 50;

    selectedSeatCount = seats.size();
    totalFare = farePerSeat * selectedSeatCount;

    grandTotal = totalFare + linerFee + insurance + serviceFee;

    lblFarePerSeat.setText(
            String.format("PHP %.2f", (double) farePerSeat));

    lblTotalFare.setText(
            String.format("PHP %.2f", (double) totalFare));

    lblLinersFee.setText(
            String.format("PHP %.2f", (double) linerFee));

    lblInsurance.setText(
            String.format("PHP %.2f", (double) insurance));

    lblServiceFee.setText(
            String.format("PHP %.2f", (double) serviceFee));

    lblNoPax.setText("" + selectedSeatCount);

    lblTotal.setText(
            String.format("PHP %.2f", grandTotal));

    lblTotalPayment.setText(
            String.format("PHP %.2f", grandTotal));
}

public void loadPassengerDetails() {

    pnlPassenger.removeAll();

    pnlPassenger.setLayout(
        new java.awt.GridLayout(0, 2, 20, 10)
    );

    for (int i = 0; i < passengerNames.size(); i++) {

        JLabel seatLabel = new JLabel(
            "Seat " + seats.get(i)
        );

        JLabel nameLabel = new JLabel(
            passengerNames.get(i)
        );

        seatLabel.setFont(
            new Font("Arial", Font.BOLD, 18)
        );

        nameLabel.setFont(
            new Font("Arial", Font.BOLD, 18)
        );

        pnlPassenger.add(seatLabel);
        pnlPassenger.add(nameLabel);
    }

    pnlPassenger.revalidate();
    pnlPassenger.repaint();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        PaymentFrame = new javax.swing.JPanel();
        lblPayment = new javax.swing.JLabel();
        btnGcash = new javax.swing.JButton();
        btnMaya = new javax.swing.JButton();
        pnlPaymentInfo = new javax.swing.JPanel();
        lblTotalPayment = new javax.swing.JLabel();
        lblTotalAmount = new javax.swing.JLabel();
        pnlBookingReminders = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblMessage = new javax.swing.JLabel();
        btnGoTyme = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        pnlBookingSummary = new javax.swing.JPanel();
        lblBookingSummary = new javax.swing.JLabel();
        lblSummaryDescriptions = new javax.swing.JLabel();
        pnlPassenger = new javax.swing.JPanel();
        lblSeatNumber = new javax.swing.JLabel();
        lblPassengerName = new javax.swing.JLabel();
        pnlPaymentDetails = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblTotalFareTitle = new javax.swing.JLabel();
        lblLinersFareTitle = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblServiceFeeTitle = new javax.swing.JLabel();
        lblNoOfPaxTitle = new javax.swing.JLabel();
        lblFarePerSeat = new javax.swing.JLabel();
        lblTotalFare = new javax.swing.JLabel();
        lblLinersFee = new javax.swing.JLabel();
        lblInsurance = new javax.swing.JLabel();
        lblServiceFee = new javax.swing.JLabel();
        lblServiceFeeTitle1 = new javax.swing.JLabel();
        lblNoPax = new javax.swing.JLabel();
        lblGrandTotal = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        lblGrandTotal1 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnPassengerDetails = new javax.swing.JToggleButton();
        btnPaymentDetails = new javax.swing.JToggleButton();
        lbl = new javax.swing.JLabel();

        jLabel7.setText("jLabel7");

        jLabel10.setBackground(new java.awt.Color(250, 248, 227));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(250, 248, 227));
        jLabel10.setText("SUPER FIVE");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PaymentFrame.setBackground(new java.awt.Color(30, 105, 75));

        lblPayment.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblPayment.setForeground(new java.awt.Color(255, 255, 255));
        lblPayment.setText("SELECT PAYMENT METHOD");

        btnGcash.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGcash.setText("Gcash/ GCredit");
        btnGcash.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnGcash.addActionListener(this::btnGcashActionPerformed);

        btnMaya.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnMaya.setText(" Maya");
        btnMaya.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnMaya.addActionListener(this::btnMayaActionPerformed);

        pnlPaymentInfo.setBackground(new java.awt.Color(255, 255, 255));

        lblTotalPayment.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblTotalAmount.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalAmount.setText("Total Payment:");

        javax.swing.GroupLayout pnlPaymentInfoLayout = new javax.swing.GroupLayout(pnlPaymentInfo);
        pnlPaymentInfo.setLayout(pnlPaymentInfoLayout);
        pnlPaymentInfoLayout.setHorizontalGroup(
            pnlPaymentInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(188, Short.MAX_VALUE))
        );
        pnlPaymentInfoLayout.setVerticalGroup(
            pnlPaymentInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPaymentInfoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTotalAmount)
                .addGap(19, 19, 19))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPaymentInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTotalPayment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlBookingReminders.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("BOOKING REMINDERS:");

        jLabel3.setText("• Don't forget to download your ticket voucher after payment. ");

        jLabel4.setText("• Retrieve your ticket voucher after booking. ");

        jLabel5.setText("• If you don't receive any confirmation, contact support.");

        javax.swing.GroupLayout pnlBookingRemindersLayout = new javax.swing.GroupLayout(pnlBookingReminders);
        pnlBookingReminders.setLayout(pnlBookingRemindersLayout);
        pnlBookingRemindersLayout.setHorizontalGroup(
            pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingRemindersLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel1))
                .addContainerGap(144, Short.MAX_VALUE))
        );
        pnlBookingRemindersLayout.setVerticalGroup(
            pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingRemindersLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        lblMessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        btnGoTyme.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGoTyme.setText("GoTyme");
        btnGoTyme.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnGoTyme.addActionListener(this::btnGoTymeActionPerformed);

        javax.swing.GroupLayout PaymentFrameLayout = new javax.swing.GroupLayout(PaymentFrame);
        PaymentFrame.setLayout(PaymentFrameLayout);
        PaymentFrameLayout.setHorizontalGroup(
            PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentFrameLayout.createSequentialGroup()
                .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PaymentFrameLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pnlBookingReminders, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnMaya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnGcash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnGoTyme, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(pnlPaymentInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(31, 31, 31)
                        .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PaymentFrameLayout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(lblPayment))
                    .addGroup(PaymentFrameLayout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PaymentFrameLayout.setVerticalGroup(
            PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentFrameLayout.createSequentialGroup()
                .addContainerGap(136, Short.MAX_VALUE)
                .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PaymentFrameLayout.createSequentialGroup()
                        .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(621, 621, 621))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PaymentFrameLayout.createSequentialGroup()
                        .addComponent(lblPayment)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(btnGcash, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnMaya, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnGoTyme, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pnlPaymentInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(pnlBookingReminders, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(209, 209, 209))))
        );

        pnlBookingSummary.setBackground(new java.awt.Color(250, 248, 227));

        lblBookingSummary.setBackground(new java.awt.Color(0, 0, 0));
        lblBookingSummary.setFont(new java.awt.Font("Segoe UI", 1, 50)); // NOI18N
        lblBookingSummary.setForeground(new java.awt.Color(30, 105, 75));
        lblBookingSummary.setText("BOOKING SUMMARY");

        lblSummaryDescriptions.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblSummaryDescriptions.setText("Review your booking details before proceeding to payment");

        pnlPassenger.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout pnlPassengerLayout = new javax.swing.GroupLayout(pnlPassenger);
        pnlPassenger.setLayout(pnlPassengerLayout);
        pnlPassengerLayout.setHorizontalGroup(
            pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPassengerLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblSeatNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91)
                .addComponent(lblPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(228, Short.MAX_VALUE))
        );
        pnlPassengerLayout.setVerticalGroup(
            pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPassengerLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSeatNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(178, Short.MAX_VALUE))
        );

        pnlPaymentDetails.setBackground(new java.awt.Color(204, 204, 204));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Fare Per Seat:");

        lblTotalFareTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTotalFareTitle.setText("Total Fare:");

        lblLinersFareTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLinersFareTitle.setText("Liners Fee:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Insurance:");

        lblServiceFeeTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblServiceFeeTitle.setText("Service Fee:");

        lblNoOfPaxTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblNoOfPaxTitle.setText("No. of Pax");

        lblFarePerSeat.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblFarePerSeat.setText("1");
        lblFarePerSeat.setPreferredSize(new java.awt.Dimension(17, 0));

        lblTotalFare.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotalFare.setText("1");

        lblLinersFee.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblLinersFee.setText("1");

        lblInsurance.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblInsurance.setText("1");

        lblServiceFee.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblServiceFee.setText("1");

        lblServiceFeeTitle1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblServiceFeeTitle1.setText("No. of Pax:");

        lblNoPax.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblNoPax.setText("1");

        lblGrandTotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotal.setText("1");

        lblGrandTotal1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGrandTotal1.setText("Total");

        javax.swing.GroupLayout pnlPaymentDetailsLayout = new javax.swing.GroupLayout(pnlPaymentDetails);
        pnlPaymentDetails.setLayout(pnlPaymentDetailsLayout);
        pnlPaymentDetailsLayout.setHorizontalGroup(
            pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(lblNoOfPaxTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblServiceFeeTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTotalFareTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLinersFareTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblServiceFeeTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblGrandTotal1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(190, 190, 190)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblLinersFee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTotalFare, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblFarePerSeat, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(lblInsurance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblServiceFee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblNoPax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblTotal, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblGrandTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPaymentDetailsLayout.setVerticalGroup(
            pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblFarePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotalFareTitle)
                    .addComponent(lblTotalFare, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLinersFee, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLinersFareTitle))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(lblInsurance, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblServiceFeeTitle)
                    .addComponent(lblServiceFee))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblServiceFeeTitle1)
                    .addComponent(lblNoPax, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblGrandTotal1)
                        .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblGrandTotal))
                .addGap(97, 97, 97)
                .addComponent(lblNoOfPaxTitle))
        );

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        btnNext.setBackground(new java.awt.Color(30, 105, 75));
        btnNext.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnNext.setForeground(new java.awt.Color(255, 255, 255));
        btnNext.setText("NEXT");
        btnNext.addActionListener(this::btnNextActionPerformed);

        btnPassengerDetails.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPassengerDetails.setForeground(new java.awt.Color(30, 105, 75));
        btnPassengerDetails.setText("PASSENGER DETAILS                             ▼");
        btnPassengerDetails.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPassengerDetails.addActionListener(this::btnPassengerDetailsActionPerformed);

        btnPaymentDetails.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPaymentDetails.setForeground(new java.awt.Color(30, 105, 75));
        btnPaymentDetails.setText("PAYMENT DETAILS                                 ▼");
        btnPaymentDetails.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPaymentDetails.addActionListener(this::btnPaymentDetailsActionPerformed);

        javax.swing.GroupLayout pnlBookingSummaryLayout = new javax.swing.GroupLayout(pnlBookingSummary);
        pnlBookingSummary.setLayout(pnlBookingSummaryLayout);
        pnlBookingSummaryLayout.setHorizontalGroup(
            pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBookingSummaryLayout.createSequentialGroup()
                .addContainerGap(405, Short.MAX_VALUE)
                .addComponent(btnBack)
                .addGap(18, 18, 18)
                .addComponent(btnNext)
                .addGap(667, 667, 667))
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                        .addGap(282, 282, 282)
                        .addComponent(lblSummaryDescriptions))
                    .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                        .addGap(243, 243, 243)
                        .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pnlPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnPassengerDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnPaymentDetails))
                                .addGap(98, 98, 98)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnlPaymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlBookingSummaryLayout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(lblBookingSummary)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlBookingSummaryLayout.setVerticalGroup(
            pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(lblBookingSummary, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSummaryDescriptions)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(btnPassengerDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(btnPaymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlPaymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBack)
                    .addComponent(btnNext))
                .addGap(40, 40, 40))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PaymentFrame, javax.swing.GroupLayout.PREFERRED_SIZE, 588, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlBookingSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlBookingSummary, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PaymentFrame, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGoTymeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoTymeActionPerformed
       paymentMethod = "GoTyme";

        btnGoTyme.setBackground(new java.awt.Color(30,105,75));
        btnGcash.setBackground(java.awt.Color.WHITE);
        btnMaya.setBackground(java.awt.Color.WHITE);
    }//GEN-LAST:event_btnGoTymeActionPerformed

    private void btnPaymentDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPaymentDetailsActionPerformed
        if (btnPaymentDetails.isSelected()) {
            pnlPaymentDetails.setVisible(true);
        } else {
            pnlPaymentDetails.setVisible(false);
        }
    }//GEN-LAST:event_btnPaymentDetailsActionPerformed

    private void btnPassengerDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPassengerDetailsActionPerformed
        if (btnPassengerDetails.isSelected()) {
            pnlPassenger.setVisible(true);
        } else {
            pnlPassenger.setVisible(false);
        }
    }//GEN-LAST:event_btnPassengerDetailsActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
     
    if (paymentMethod == null) {
        lbl.setText("Please select a payment method.");
        return;
    }

    if (paymentMethod.toLowerCase().contains("gcash")) {
        GcashFrame gcash = new GcashFrame();
        gcash.totalAmount = grandTotal;
        gcash.paymentMethod = paymentMethod;
        gcash.from = from;
        gcash.to = to;
        gcash.travelDate = travelDate;
        gcash.tripTime = tripTime;
        gcash.pickupTime = pickupTime;
        gcash.tripCode = tripCode;
        gcash.farePerSeat = farePerSeat;
        gcash.totalFare = totalFare;
        gcash.contactNumber = contactNumber;
        gcash.email = email;
        gcash.passengerNames.addAll(passengerNames);
        gcash.seats.addAll(seats);
        gcash.firstNames.addAll(firstNames);
        gcash.lastNames.addAll(lastNames);
        gcash.loadAmount();
        gcash.setVisible(true);

    } else if (paymentMethod.equalsIgnoreCase("Maya")) {

        MayaFrame maya = new MayaFrame();
        maya.totalAmount = grandTotal;
        maya.paymentMethod = paymentMethod;
        maya.from = from;
        maya.to = to;
        maya.travelDate = travelDate;
        maya.tripTime = tripTime;
        maya.pickupTime = pickupTime;
        maya.tripCode = tripCode;
        maya.farePerSeat = farePerSeat;
        maya.totalFare = totalFare;
        maya.contactNumber = contactNumber;
        maya.email = email;
        maya.passengerNames.addAll(passengerNames);
        maya.seats.addAll(seats);
        maya.firstNames.addAll(firstNames);
        maya.lastNames.addAll(lastNames);
        maya.loadAmount();
        maya.setVisible(true);

    } else if (paymentMethod.equalsIgnoreCase("GoTyme")) {

        GoTymeFrame go = new GoTymeFrame();
        go.totalAmount = grandTotal;
        go.paymentMethod = paymentMethod;
        go.from = from;
        go.to = to;
        go.travelDate = travelDate;
        go.tripTime = tripTime;
        go.pickupTime = pickupTime;
        go.tripCode = tripCode;
        go.farePerSeat = farePerSeat;
        go.totalFare = totalFare;
        go.contactNumber = contactNumber;
        go.email = email;
        go.passengerNames.addAll(passengerNames);
        go.seats.addAll(seats);
        go.firstNames.addAll(firstNames);
        go.lastNames.addAll(lastNames);
        go.loadAmount();
        go.setVisible(true);

    } else {
        lbl.setText("Invalid payment method selected.");
        return;
    }
    this.dispose();

    }//GEN-LAST:event_btnNextActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        PassengerDetailsFrame passenger = new PassengerDetailsFrame();

        passenger.from = from;
        passenger.to = to;
        passenger.travelDate = travelDate;
        passenger.tripTime = tripTime;
        passenger.pickupTime = pickupTime;
        passenger.tripCode = tripCode;
        passenger.busType = busType;

        passenger.farePerSeat = farePerSeat;
        passenger.selectedSeatCount = selectedSeatCount;
        passenger.totalFare = totalFare;

        passenger.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnMayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMayaActionPerformed
        paymentMethod = "Maya";

        btnMaya.setBackground(new java.awt.Color(30,105,75));
        btnGcash.setBackground(java.awt.Color.WHITE);
        btnGoTyme.setBackground(java.awt.Color.WHITE);
    }//GEN-LAST:event_btnMayaActionPerformed

    private void btnGcashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGcashActionPerformed
        paymentMethod = "GCash / GCredit";

        btnGcash.setBackground(new java.awt.Color(30,105,75));
        btnMaya.setBackground(java.awt.Color.WHITE);
        btnGoTyme.setBackground(java.awt.Color.WHITE);
    }//GEN-LAST:event_btnGcashActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PaymentFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PaymentFrame;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnGcash;
    private javax.swing.JButton btnGoTyme;
    private javax.swing.JButton btnMaya;
    private javax.swing.JButton btnNext;
    private javax.swing.JToggleButton btnPassengerDetails;
    private javax.swing.JToggleButton btnPaymentDetails;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lblBookingSummary;
    private javax.swing.JLabel lblFarePerSeat;
    private javax.swing.JLabel lblGrandTotal;
    private javax.swing.JLabel lblGrandTotal1;
    private javax.swing.JLabel lblInsurance;
    private javax.swing.JLabel lblLinersFareTitle;
    private javax.swing.JLabel lblLinersFee;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblNoOfPaxTitle;
    private javax.swing.JLabel lblNoPax;
    private javax.swing.JLabel lblPassengerName;
    private javax.swing.JLabel lblPayment;
    private javax.swing.JLabel lblSeatNumber;
    private javax.swing.JLabel lblServiceFee;
    private javax.swing.JLabel lblServiceFeeTitle;
    private javax.swing.JLabel lblServiceFeeTitle1;
    private javax.swing.JLabel lblSummaryDescriptions;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JLabel lblTotalAmount;
    private javax.swing.JLabel lblTotalFare;
    private javax.swing.JLabel lblTotalFareTitle;
    private javax.swing.JLabel lblTotalPayment;
    private javax.swing.JPanel pnlBookingReminders;
    private javax.swing.JPanel pnlBookingSummary;
    private javax.swing.JPanel pnlPassenger;
    private javax.swing.JPanel pnlPaymentDetails;
    private javax.swing.JPanel pnlPaymentInfo;
    // End of variables declaration//GEN-END:variables
}
