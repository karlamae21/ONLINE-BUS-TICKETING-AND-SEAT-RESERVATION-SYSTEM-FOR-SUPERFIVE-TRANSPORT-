package Database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {

    // Usba ra kini kung lahi imong MySQL settings
    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    public static final String DB_NAME = "superfive";
    private static final String USER = "root";
    private static final String PASS = "";

    // Connect sa mismong database (superfive)
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(
                    "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME
                    + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
                    USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Connect sa MySQL server lang (gamit pang create sa database)
    public static Connection getServerConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(
                    "jdbc:mysql://" + HOST + ":" + PORT + "/"
                    + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
                    USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
