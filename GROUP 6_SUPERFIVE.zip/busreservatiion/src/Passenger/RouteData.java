package Passenger;

import javax.swing.JComboBox;

public class RouteData {

    public static void setRoute(JComboBox cmbPickup1, JComboBox cmbDropoff1,
            String from, String to) {

        cmbPickup1.removeAllItems();
        cmbDropoff1.removeAllItems();

        cmbPickup1.addItem(from);

        if (from.equals("CDO") && to.equals("Wao")) {

            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Maramag");
            cmbDropoff1.addItem("Don Carlos");
            cmbDropoff1.addItem("Kalilangan");
            cmbDropoff1.addItem("Wao (Abtanan)");

        } else if (from.equals("Wao") && to.equals("CDO")) {

            cmbDropoff1.addItem("Kalilangan");
            cmbDropoff1.addItem("Don Carlos");
            cmbDropoff1.addItem("Maramag");
            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("CDO (Abtanan)");

        } else if (from.equals("CDO") && to.equals("Dipolog")) {

            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Tangub City");
            cmbDropoff1.addItem("Ozamiz City");
            cmbDropoff1.addItem("Clarin");
            cmbDropoff1.addItem("Tudela");
            cmbDropoff1.addItem("Sinacaban");
            cmbDropoff1.addItem("Jimenez");
            cmbDropoff1.addItem("Panaon");
            cmbDropoff1.addItem("Aloran");
            cmbDropoff1.addItem("Oroquieta City");
            cmbDropoff1.addItem("Lopez Jaena");
            cmbDropoff1.addItem("Plaridel");
            cmbDropoff1.addItem("Calamba");
            cmbDropoff1.addItem("Sapang Dalaga");
            cmbDropoff1.addItem("Rizal");
            cmbDropoff1.addItem("Sibutad");
            cmbDropoff1.addItem("Dapitan City");
            cmbDropoff1.addItem("Dipolog City (Abtanan)");

        } else if (from.equals("Dipolog") && to.equals("CDO")) {

            cmbDropoff1.addItem("Dapitan City");
            cmbDropoff1.addItem("Sibutad");
            cmbDropoff1.addItem("Rizal");
            cmbDropoff1.addItem("Sapang Dalaga");
            cmbDropoff1.addItem("Calamba");
            cmbDropoff1.addItem("Plaridel");
            cmbDropoff1.addItem("Lopez Jaena");
            cmbDropoff1.addItem("Oroquieta City");
            cmbDropoff1.addItem("Aloran");
            cmbDropoff1.addItem("Panaon");
            cmbDropoff1.addItem("Jimenez");
            cmbDropoff1.addItem("Sinacaban");
            cmbDropoff1.addItem("Tudela");
            cmbDropoff1.addItem("Clarin");
            cmbDropoff1.addItem("Ozamiz City");
            cmbDropoff1.addItem("Tangub City");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("CDO (Abtanan)");

        } else if (from.equals("CDO") && to.equals("Pagadian")) {

            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Lala");
            cmbDropoff1.addItem("Kapatagan");
            cmbDropoff1.addItem("Aurora");
            cmbDropoff1.addItem("Tambulig / Ramon Magsaysay");
            cmbDropoff1.addItem("Labangan");
            cmbDropoff1.addItem("Pagadian City (Abtanan)");

        } else if (from.equals("Pagadian") && to.equals("CDO")) {

            cmbDropoff1.addItem("Labangan");
            cmbDropoff1.addItem("Tambulig / Ramon Magsaysay");
            cmbDropoff1.addItem("Aurora");
            cmbDropoff1.addItem("Kapatagan");
            cmbDropoff1.addItem("Lala");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("CDO (Abtanan)");

        } else if (from.equals("CDO") && to.equals("Maramag")) {

            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Maramag (Abtanan)");

        } else if (from.equals("Maramag") && to.equals("CDO")) {

            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("CDO (Abtanan)");

        } else if (from.equals("CDO") && to.equals("Tubod")) {

            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Tubod (Abtanan)");

        } else if (from.equals("Tubod") && to.equals("CDO")) {

            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("CDO (Abtanan)");

        } else if (from.equals("CDO") && to.equals("Kibawe")) {

            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Maramag");
            cmbDropoff1.addItem("Don Carlos");
            cmbDropoff1.addItem("Kibawe (Abtanan)");

        } else if (from.equals("Kibawe") && to.equals("CDO")) {

            cmbDropoff1.addItem("Don Carlos");
            cmbDropoff1.addItem("Maramag");
            cmbDropoff1.addItem("Valencia City");
            cmbDropoff1.addItem("Malaybalay City");
            cmbDropoff1.addItem("Impasugong");
            cmbDropoff1.addItem("Sumilao");
            cmbDropoff1.addItem("Manolo Fortich");
            cmbDropoff1.addItem("CDO (Abtanan)");
            
        } else if (from.equals("CDO") && to.equalsIgnoreCase("Ozamiz")) {

            cmbPickup1.removeAllItems();
            cmbDropoff1.removeAllItems();

            cmbPickup1.addItem("CDO");

            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Tangub City");
            cmbDropoff1.addItem("Ozamiz City (Abtanan)");

            
        } else if (from.equalsIgnoreCase("Ozamiz") && to.equalsIgnoreCase("CDO")) {

            cmbPickup1.removeAllItems();
            cmbDropoff1.removeAllItems();

            cmbPickup1.addItem("Ozamiz");

            cmbDropoff1.addItem("Tangub City");
            cmbDropoff1.addItem("Tubod");
            cmbDropoff1.addItem("Kolambugan");
            cmbDropoff1.addItem("Maigo");
            cmbDropoff1.addItem("Bacolod");
            cmbDropoff1.addItem("Kauswagan");
            cmbDropoff1.addItem("Linamon");
            cmbDropoff1.addItem("Iligan City");
            cmbDropoff1.addItem("Lugait");
            cmbDropoff1.addItem("Naawan");
            cmbDropoff1.addItem("Initao");
            cmbDropoff1.addItem("Gitagum");
            cmbDropoff1.addItem("Laguindingan");
            cmbDropoff1.addItem("Alubijid");
            cmbDropoff1.addItem("El Salvador City");
            cmbDropoff1.addItem("Opol");
            cmbDropoff1.addItem("CDO (Abtanan)");

}
 }
    }