/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package LoginRegister;

/**
 *
 * @author Admin
 */
public class ForgotPasswordFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ForgotPasswordFrame.class.getName());

    /**
     * Creates new form ForgotPasswordFrame
     */
    public ForgotPasswordFrame() {
        initComponents();
            setupResponsiveLayout();

    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    setMinimumSize(new java.awt.Dimension(700, 500));
    }
   private void setupResponsiveLayout() {
    getContentPane().removeAll();
    getContentPane().setLayout(new java.awt.BorderLayout());
    getContentPane().setBackground(new java.awt.Color(215, 219, 224));

    pnlForgot.removeAll();
    pnlForgot.setBackground(new java.awt.Color(250, 248, 237));
    pnlForgot.setLayout(new java.awt.GridBagLayout());

    java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
    gbc.gridx = 0;
    gbc.weightx = 1.0;
    gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gbc.insets = new java.awt.Insets(6, 0, 6, 0);

    javax.swing.JPanel form = new javax.swing.JPanel(
            new java.awt.GridBagLayout());
    form.setOpaque(false);

    java.awt.GridBagConstraints f = new java.awt.GridBagConstraints();
    f.gridx = 0;
    f.weightx = 1.0;
    f.fill = java.awt.GridBagConstraints.HORIZONTAL;
    f.insets = new java.awt.Insets(6, 0, 6, 0);

    lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    lblTitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 36));

    lblFullname.setText("Enter Username/Email");
    lblPassword1.setText("Security Questions");
    lblPassword3.setText("Security Answer");

    txtUsernameEmail.setPreferredSize(new java.awt.Dimension(400, 32));
    cmbSecurityQuestions.setPreferredSize(new java.awt.Dimension(400, 32));
    txtSecurityAnswer.setPreferredSize(new java.awt.Dimension(400, 32));

    f.gridy = 0;
    form.add(lblTitle, f);

    f.gridy = 1;
    form.add(lblFullname, f);

    f.gridy = 2;
    form.add(txtUsernameEmail, f);

    f.gridy = 3;
    form.add(lblPassword1, f);

    f.gridy = 4;
    form.add(cmbSecurityQuestions, f);

    f.gridy = 5;
    form.add(lblPassword3, f);

    f.gridy = 6;
    form.add(txtSecurityAnswer, f);

    label.setForeground(java.awt.Color.RED);
    f.gridy = 7;
    form.add(label, f);

    javax.swing.JPanel buttons = new javax.swing.JPanel(
            new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 25, 5));
    buttons.setOpaque(false);
    buttons.add(btnVerify);
    buttons.add(btnBack);

    f.gridy = 8;
    form.add(buttons, f);

    gbc.gridy = 0;
    gbc.weighty = 1.0;
    gbc.anchor = java.awt.GridBagConstraints.CENTER;
    gbc.fill = java.awt.GridBagConstraints.NONE;
    pnlForgot.add(form, gbc);

    // Form width adjusts to the available window width.
    form.setPreferredSize(new java.awt.Dimension(650, 430));

    getContentPane().add(pnlForgot, java.awt.BorderLayout.CENTER);

    // Resize the form and its fonts when the window changes size.
    addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent e) {
            int w = getContentPane().getWidth();
            int h = getContentPane().getHeight();

            double scale = Math.min(w / 1000.0, h / 650.0);
            scale = Math.max(0.75, Math.min(scale, 1.5));

            int formWidth = Math.min(w - 60, (int) (650 * scale));
            formWidth = Math.max(300, formWidth);
            form.setPreferredSize(new java.awt.Dimension(
                    formWidth, (int) (430 * scale)));

            lblTitle.setFont(new java.awt.Font(
                    "Segoe UI", java.awt.Font.BOLD,
                    Math.max(22, (int) (36 * scale))));

            java.awt.Font normal = new java.awt.Font(
                    "Segoe UI", java.awt.Font.PLAIN,
                    Math.max(12, (int) (14 * scale)));

            lblFullname.setFont(normal);
            lblPassword1.setFont(normal);
            lblPassword3.setFont(normal);

            txtUsernameEmail.setPreferredSize(new java.awt.Dimension(
                    formWidth, Math.max(28, (int) (32 * scale))));
            cmbSecurityQuestions.setPreferredSize(new java.awt.Dimension(
                    formWidth, Math.max(28, (int) (32 * scale))));
            txtSecurityAnswer.setPreferredSize(new java.awt.Dimension(
                    formWidth, Math.max(28, (int) (32 * scale))));

            btnVerify.setFont(new java.awt.Font(
                    "Segoe UI", java.awt.Font.BOLD,
                    Math.max(10, (int) (12 * scale))));
            btnBack.setFont(new java.awt.Font(
                    "Segoe UI", java.awt.Font.BOLD,
                    Math.max(10, (int) (12 * scale))));

            pnlForgot.revalidate();
            pnlForgot.repaint();
        }
    });

    revalidate();
    repaint();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlForgot = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblFullname = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();
        lblPassword = new javax.swing.JLabel();
        txtUsernameEmail = new javax.swing.JTextField();
        txtSecurityAnswer = new javax.swing.JTextField();
        btnVerify = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblMessage = new javax.swing.JLabel();
        lblfullname = new javax.swing.JLabel();
        lblemail = new javax.swing.JLabel();
        lblusername = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        lblmessage = new javax.swing.JLabel();
        lbluser = new javax.swing.JLabel();
        lbl = new javax.swing.JLabel();
        cmbSecurityQuestions = new javax.swing.JComboBox<>();
        lblPassword1 = new javax.swing.JLabel();
        lblPassword3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlForgot.setBackground(new java.awt.Color(250, 248, 237));

        lblTitle.setBackground(new java.awt.Color(30, 105, 75));
        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(30, 105, 75));
        lblTitle.setText("FORGOT PASSWORD");

        lblFullname.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblFullname.setText("Enter Username/Email");

        lblUsername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblPassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtUsernameEmail.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N

        txtSecurityAnswer.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        txtSecurityAnswer.addActionListener(this::txtSecurityAnswerActionPerformed);

        btnVerify.setBackground(new java.awt.Color(30, 105, 75));
        btnVerify.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVerify.setForeground(new java.awt.Color(255, 255, 255));
        btnVerify.setText("VERIFY");
        btnVerify.addActionListener(this::btnVerifyActionPerformed);

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        lblfullname.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N

        lblemail.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N

        lblusername.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N

        Email.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N

        username.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N

        label.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N

        lblmessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        lbluser.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        lbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        cmbSecurityQuestions.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        cmbSecurityQuestions.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. What is your mother's name?", "2. What is the name of your first pet?", "3. What is your favorite food?", "4. What is your favorite color?", "5. What is your favorite place?" }));

        lblPassword1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblPassword1.setText("Security Questions");

        lblPassword3.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblPassword3.setText("Security Answer");

        javax.swing.GroupLayout pnlForgotLayout = new javax.swing.GroupLayout(pnlForgot);
        pnlForgot.setLayout(pnlForgotLayout);
        pnlForgotLayout.setHorizontalGroup(
            pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlForgotLayout.createSequentialGroup()
                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlForgotLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblemail, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlForgotLayout.createSequentialGroup()
                        .addGap(189, 189, 189)
                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lblmessage, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addGap(679, 679, 679)
                                        .addComponent(lblfullname, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addGap(142, 142, 142)
                                        .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                                .addGap(509, 509, 509)
                                                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(lblPassword1)
                                                .addGap(420, 420, 420)
                                                .addComponent(lbluser, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addGap(599, 599, 599)
                                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(Email, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addComponent(lblPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(662, 662, 662)
                                        .addComponent(lblUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 227, Short.MAX_VALUE)))))
                .addGap(41, 232, Short.MAX_VALUE))
            .addGroup(pnlForgotLayout.createSequentialGroup()
                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlForgotLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPassword3)
                            .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtUsernameEmail)
                                .addComponent(lblFullname, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbSecurityQuestions, 0, 574, Short.MAX_VALUE))
                            .addComponent(txtSecurityAnswer, javax.swing.GroupLayout.PREFERRED_SIZE, 574, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlForgotLayout.createSequentialGroup()
                        .addGap(608, 608, 608)
                        .addComponent(lblTitle))
                    .addGroup(pnlForgotLayout.createSequentialGroup()
                        .addGap(671, 671, 671)
                        .addComponent(btnVerify, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlForgotLayout.setVerticalGroup(
            pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlForgotLayout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(lblmessage)
                .addGap(16, 16, 16)
                .addComponent(lblTitle)
                .addGap(41, 41, 41)
                .addComponent(Email)
                .addGap(8, 8, 8)
                .addComponent(lblFullname, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtUsernameEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlForgotLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlForgotLayout.createSequentialGroup()
                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlForgotLayout.createSequentialGroup()
                                        .addGap(42, 42, 42)
                                        .addComponent(lblUsername))
                                    .addComponent(lbluser))
                                .addGap(32, 32, 32))
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addComponent(lblPassword1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbSecurityQuestions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addComponent(lblPassword3)
                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(txtSecurityAnswer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGap(126, 126, 126)
                                .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnVerify)
                                    .addComponent(btnBack))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)))
                        .addGroup(pnlForgotLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlForgotLayout.createSequentialGroup()
                                .addGap(122, 122, 122)
                                .addComponent(lblfullname)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                                .addComponent(lblemail)
                                .addGap(51, 51, 51))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlForgotLayout.createSequentialGroup()
                                .addGap(110, 110, 110)
                                .addComponent(username)
                                .addGap(35, 35, 35)))))
                .addGap(17, 17, 17)
                .addComponent(lblPassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlForgot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(pnlForgot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSecurityAnswerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSecurityAnswerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSecurityAnswerActionPerformed

    private void btnVerifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerifyActionPerformed
    String usernameEmail = txtUsernameEmail.getText().trim();
    String answer = txtSecurityAnswer.getText().trim();
    String question = cmbSecurityQuestions.getSelectedItem().toString();

    if (usernameEmail.isEmpty() || answer.isEmpty()) {
        label.setText("Please complete all fields.");
        return;
    }

    String savedQuestion =
            Database.UserDB.getSecurityQuestion(usernameEmail);

    if (savedQuestion == null) {
        label.setText("Username or email not found.");
           return;
    }

    if (!savedQuestion.equals(question)) {
        label.setText("Wrong security question.");
        return;
    }

    if (!Database.UserDB.verifySecurityAnswer(usernameEmail, answer)) {
        label.setText("Wrong security answer.");
        return;
    }

    javax.swing.JPasswordField newPass = new javax.swing.JPasswordField();
    javax.swing.JPasswordField confirmPass = new javax.swing.JPasswordField();

    Object[] fields = {
        "New Password:", newPass,
        "Confirm Password:", confirmPass
    };

    int choice = javax.swing.JOptionPane.showConfirmDialog(
            this, fields, "Change Password",
            javax.swing.JOptionPane.OK_CANCEL_OPTION
    );

    if (choice != javax.swing.JOptionPane.OK_OPTION) {
        return;
    }

    String password = new String(newPass.getPassword());
    String confirm = new String(confirmPass.getPassword());

    if (password.length() < 8) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Password must be at least 8 characters.");
        return;
    }

    if (!password.equals(confirm)) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Passwords do not match.");
        return;
    }

    if (Database.UserDB.updatePassword(usernameEmail, password)) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Password changed successfully!");
        this.dispose();
    } else {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Failed to change password.");
    }
       
    }//GEN-LAST:event_btnVerifyActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
   
    SuperFiveFrame frame = new SuperFiveFrame();
    frame.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ForgotPasswordFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Email;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnVerify;
    private javax.swing.JComboBox<String> cmbSecurityQuestions;
    private javax.swing.JLabel label;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lblFullname;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblPassword1;
    private javax.swing.JLabel lblPassword3;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JLabel lblemail;
    private javax.swing.JLabel lblfullname;
    private javax.swing.JLabel lblmessage;
    private javax.swing.JLabel lbluser;
    private javax.swing.JLabel lblusername;
    private javax.swing.JPanel pnlForgot;
    private javax.swing.JTextField txtSecurityAnswer;
    private javax.swing.JTextField txtUsernameEmail;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables

    public void setVisible() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
