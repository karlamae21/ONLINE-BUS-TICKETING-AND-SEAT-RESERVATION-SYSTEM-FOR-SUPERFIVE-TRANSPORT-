
package Database;

import LoginRegister.PassengerAdminAccount;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class UserDB {

    // REGISTER PASSENGER
    public static String registerUser(
            String fullName,
            String email,
            String username,
            String password,
            String question,
            String answer) {

        try (Connection con = DbConnection.getConnection()) {

            if (con == null) {
                return "Cannot connect to database.";
            }

            String checkSql =
                    "SELECT user_id FROM users WHERE username = ?";

            try (PreparedStatement check =
                    con.prepareStatement(checkSql)) {

                check.setString(1, username);

                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) {
                        return "Username already exists.";
                    }
                }
            }

            String sql = "INSERT INTO users "
                    + "(full_name, email, username, password, "
                    + "security_question, security_answer) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, fullName);
                ps.setString(2, email);
                ps.setString(3, username);
                ps.setString(4, password);
                ps.setString(5, question);
                ps.setString(6, answer.trim());

                ps.executeUpdate();
            }

            return null;

        } catch (Exception e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    // PASSENGER LOGIN
    public static boolean loginUser(
            String username, String password) {

        String sql = "SELECT user_id, full_name, email "
                + "FROM users WHERE username = ? AND password = ?";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    PassengerAdminAccount.userId =
                            rs.getInt("user_id");
                    PassengerAdminAccount.fullName =
                            rs.getString("full_name");
                    PassengerAdminAccount.email =
                            rs.getString("email");
                    PassengerAdminAccount.username = username;
                    PassengerAdminAccount.password = password;

                    return true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ADMIN LOGIN
    public static boolean loginAdmin(
            String username, String password) {

        String sql =
                "SELECT admin_id FROM admin "
                + "WHERE username = ? AND password = ?";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // FORGOT PASSWORD
    public static void forgotPassword() {

        String username = JOptionPane.showInputDialog(
                null,
                "Enter your registered username:",
                "Forgot Password",
                JOptionPane.QUESTION_MESSAGE);

        if (username == null || username.trim().isEmpty()) {
            return;
        }

        username = username.trim();

        String question = null;

        // Get the registered security question
        String selectSql =
                "SELECT security_question, security_answer "
                + "FROM users WHERE username = ?";

        String savedAnswer = null;

        try (Connection con = DbConnection.getConnection()) {

            if (con == null) {
                JOptionPane.showMessageDialog(
                        null, "Cannot connect to database.");
                return;
            }

            try (PreparedStatement ps =
                    con.prepareStatement(selectSql)) {

                ps.setString(1, username);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        question =
                                rs.getString("security_question");
                        savedAnswer =
                                rs.getString("security_answer");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(
                    null, "Database error: " + e.getMessage());
            return;
        }

        if (question == null || savedAnswer == null) {
            JOptionPane.showMessageDialog(
                    null,
                    "Username not found or security question is missing.");
            return;
        }

        // Show the user's security question
        JOptionPane.showMessageDialog(
                null,
                question,
                "Security Question",
                JOptionPane.QUESTION_MESSAGE);

        String answer = JOptionPane.showInputDialog(
                null,
                "Enter your security answer:",
                "Verify Account",
                JOptionPane.QUESTION_MESSAGE);

        if (answer == null) {
            return;
        }

        // Check the answer
        if (!answer.trim().equalsIgnoreCase(savedAnswer.trim())) {
            JOptionPane.showMessageDialog(
                    null, "Incorrect security answer.");
            return;
        }

        // Ask for a new password
        String newPassword = JOptionPane.showInputDialog(
                null,
                "Enter your new password "
                + "(at least 8 characters, with letters, numbers, "
                + "and a symbol):",
                "Reset Password",
                JOptionPane.QUESTION_MESSAGE);

        if (newPassword == null || newPassword.isEmpty()) {
            return;
        }

        if (!newPassword.matches(
                "^(?=.*[A-Za-z])(?=.*[0-9])"
                + "(?=.*[!@#$%^&*]).{8,}$")) {

            JOptionPane.showMessageDialog(
                    null,
                    "Password must have at least 8 characters, "
                    + "letters, numbers, and a symbol.");
            return;
        }

        // Update the password
        String updateSql =
                "UPDATE users SET password = ? WHERE username = ?";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps =
                    con.prepareStatement(updateSql)) {

            if (con == null) {
                JOptionPane.showMessageDialog(
                        null, "Cannot connect to database.");
                return;
            }

            ps.setString(1, newPassword);
            ps.setString(2, username);

            int updated = ps.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(
                        null,
                        "Password reset successful! "
                        + "You can now log in.");
            } else {
                JOptionPane.showMessageDialog(
                        null, "Password reset failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(
                    null, "Database error: " + e.getMessage());
        }
    }
    
    public static String getSecurityQuestion(String username) {
    String sql = "SELECT security_question FROM users WHERE username = ?";

    try (Connection con = DbConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, username);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getString("security_question");
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return null;
}

public static boolean verifySecurityAnswer(
        String username, String answer) {

    String sql = "SELECT security_answer FROM users WHERE username = ?";

    try (Connection con = DbConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, username);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String savedAnswer = rs.getString("security_answer");

                return savedAnswer != null
                        && answer != null
                        && savedAnswer.trim().equalsIgnoreCase(answer.trim());
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return false;
}

public static boolean updatePassword(
        String username, String newPassword) {

    String sql = "UPDATE users SET password = ? WHERE username = ?";

    try (Connection con = DbConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, newPassword);
        ps.setString(2, username);

        return ps.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
    }

    return false;
}
}
