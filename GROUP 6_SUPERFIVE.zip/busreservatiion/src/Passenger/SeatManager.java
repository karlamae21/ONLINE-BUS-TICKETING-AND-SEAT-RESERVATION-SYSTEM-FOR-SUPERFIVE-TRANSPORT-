package Passenger;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JButton;

public class SeatManager {

    public static int availableSeats = 44;

    // Ang biyahe (schedule) nga gipili sa passenger gikan sa dashboard
    public static int scheduleId = 0;
    public static int dbFare = 0;
    
    public static ArrayList<Integer> selectedSeats = new ArrayList<>();

    public static void selectSeat(JButton seat) {

        int seatNumber = Integer.parseInt(seat.getText());

        if (seat.getBackground().equals(Color.BLUE)) {
            seat.setBackground(Color.WHITE);
            availableSeats++;

            selectedSeats.remove(Integer.valueOf(seatNumber));

        } else {
            seat.setBackground(Color.BLUE);
            availableSeats--;
            selectedSeats.add(seatNumber);
        }
    }
    public static void reserveSeat(JButton seat) {

        seat.setBackground(Color.GRAY);
        seat.setEnabled(false);
    }
}
