
package Passenger;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
public final class PassengerDetailsFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PassengerDetailsFrame.class.getName());
    
    ArrayList<JTextField> firstNames = new ArrayList<>();
    ArrayList<JTextField> lastNames = new ArrayList<>();    
    
    public String from;
    public String to;
    public String travelDate;
    public String tripTime;
    public String pickupTime;
    public String tripCode;
    public String busType;

    public int farePerSeat;
    public int selectedSeatCount;
    public int totalFare;
    public int discountedPassengerCount = 0;
    
   public PassengerDetailsFrame() {

    initComponents();

    contactNumberOnly();


    pnlPassengerSummary.setVisible(false);

    loadPassengerDetails(SeatManager.selectedSeats.size());
   
    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

}   
   
  public PassengerDetailsFrame(
        String from,
        String to,
        String tripTime,
        String tripCode) {

    initComponents();

    this.from = from;
    this.to = to;
    this.pickupTime = tripTime;
    this.tripCode = tripCode;

    loadPassengerDetails(SeatManager.selectedSeats.size());
  }
private void loadPassengerDetails(int numberOfSeats) {

    JPanel panel = new JPanel();

    panel.setLayout(
        new BoxLayout(panel, BoxLayout.Y_AXIS)
    );

    panel.setBackground(
        new java.awt.Color(255,255,255)
    );

    for (int i = 0; i < numberOfSeats; i++) {

    JLabel passenger = new JLabel(
        "Passenger " + (i + 1)
    );

    passenger.setForeground(Color.WHITE);
    passenger.setFont(
        new Font("Arial", Font.BOLD, 18)
    );

    JLabel seatNumber = new JLabel(
    "" + SeatManager.selectedSeats.get(i)
    );

    seatNumber.setForeground(Color.BLACK);
    seatNumber.setFont(
        new Font("Arial", Font.BOLD, 18)
    );

    JTextField firstName =
        new JTextField("First Name*");

    JTextField lastName =
        new JTextField("Last Name*");
    
    firstName.addKeyListener(new java.awt.event.KeyAdapter() {
        
    @Override
    public void keyTyped(java.awt.event.KeyEvent e) {
        if (!Character.isLetter(e.getKeyChar()) && e.getKeyChar() != ' ') {
            e.consume();
        }
    }
});
lastName.addKeyListener(new java.awt.event.KeyAdapter() {
    @Override
    public void keyTyped(java.awt.event.KeyEvent e) {
        if (!Character.isLetter(e.getKeyChar()) && e.getKeyChar() != ' ') {
            e.consume();
        }
    }
});
    firstNames.add(firstName);
    lastNames.add(lastName);
    
    firstName.addKeyListener(
    new java.awt.event.KeyAdapter() {
        @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                updatePassengerSummary();
            }
        }
    );

    lastName.addKeyListener(
        new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                updatePassengerSummary();
            }
        }
    );

    addWatermark(firstName, "First Name*");
    addWatermark(lastName, "Last Name*");

 JPanel namePanel = new JPanel(
    new BorderLayout(8, 0)
    );

    seatNumber.setPreferredSize(
        new Dimension(35, 35)
    );

    JPanel nameFields = new JPanel(
        new GridLayout(1, 2, 8, 0)
    );

    nameFields.add(firstName);
    nameFields.add(lastName);

    namePanel.add(seatNumber, BorderLayout.WEST);
    namePanel.add(nameFields, BorderLayout.CENTER);

    panel.add(passenger);
    panel.add(namePanel);
    panel.add(
        Box.createVerticalStrut(25) );
    }
    jScrollPane1.setViewportView(panel);
    updatePassengerSummary();
    }
 private void addWatermark(
    JTextField field,
    String text
) {

    field.setForeground(Color.GRAY);

    field.addFocusListener(
        new java.awt.event.FocusAdapter() {

            @Override
            public void focusGained(
                java.awt.event.FocusEvent e
            ) {
                if (field.getText().equals(text)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(
                java.awt.event.FocusEvent e
            ) {
                if (field.getText().isEmpty()) {
                    field.setText(text);
                    field.setForeground(Color.GRAY);
                }
            }
        }
    );
}
 
  private void contactNumberOnly() {

    txtContactNumber.addKeyListener(new java.awt.event.KeyAdapter() {

        @Override
        public void keyTyped(java.awt.event.KeyEvent e) {

            char c = e.getKeyChar();

            if (!Character.isDigit(c)) {
                e.consume();
            }
            
            if (txtContactNumber.getText().length() >= 10) {
                e.consume();
            }

            if (txtContactNumber.getText().length() == 0 && c != '9') {
                e.consume();
            }
        }
    });
}
    
   
private void updatePassengerSummary() {

    pnlPassengerSummary.removeAll();

    pnlPassengerSummary.setLayout(
        new BoxLayout(pnlPassengerSummary, BoxLayout.Y_AXIS)
    );

    for (int i = 0; i < firstNames.size(); i++) {

        if (i >= SeatManager.selectedSeats.size()) {
            break;
        }

        int seat = SeatManager.selectedSeats.get(i);

        String first = firstNames.get(i).getText().trim();
        String last = lastNames.get(i).getText().trim();

        if (first.equals("First Name*")) {
            first = "";
        }

        if (last.equals("Last Name*")) {
            last = "";
        }

        JLabel passenger = new JLabel(
            "Seat " + seat + "     " + first + " " + last
        );

        passenger.setFont(new Font("Arial", Font.BOLD, 18));
        passenger.setForeground(Color.BLACK);

        pnlPassengerSummary.add(passenger);
        pnlPassengerSummary.add(Box.createVerticalStrut(15));
        pnlPassengerSummary.setPreferredSize(new Dimension(200, 429));

        

    }

    pnlPassengerSummary.revalidate();
    pnlPassengerSummary.repaint();
}

    
    private boolean sameName(String first, String last, int current) {

    for (int i = 0; i < firstNames.size(); i++) {

        if (i == current) {
            continue;
        }

        String oldFirst = firstNames.get(i).getText();
        String oldLast = lastNames.get(i).getText();

        if (first.equalsIgnoreCase(oldFirst)
                && last.equalsIgnoreCase(oldLast)) {

            return true;
        }
    }

    return false;
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        ContactDetails = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        txtContactNumber = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtConfirmEmail = new javax.swing.JTextField();
        chkNoEmail = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        pnlPassengerSummary = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnPassengerDetails = new javax.swing.JToggleButton();
        lblMessage = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ContactDetails.setBackground(new java.awt.Color(250, 248, 227));
        ContactDetails.setPreferredSize(new java.awt.Dimension(1000, 700));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("CONTACT DETAILS");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Mobile Number");

        jLabel3.setText("Provide an active email address and mobile number to receive an instant confirmation of your booking.");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "+63" }));

        txtContactNumber.addActionListener(this::txtContactNumberActionPerformed);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Email Address");

        txtEmail.setText("Email Address");
        txtEmail.addActionListener(this::txtEmailActionPerformed);

        txtConfirmEmail.setText(" Confirm Email Address");
        txtConfirmEmail.addActionListener(this::txtConfirmEmailActionPerformed);

        chkNoEmail.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        chkNoEmail.setText("I don't have an email address");
        chkNoEmail.addActionListener(this::chkNoEmailActionPerformed);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel5.setText("PASSENGER DETAILS");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Full name is required");

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout ContactDetailsLayout = new javax.swing.GroupLayout(ContactDetails);
        ContactDetails.setLayout(ContactDetailsLayout);
        ContactDetailsLayout.setHorizontalGroup(
            ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContactDetailsLayout.createSequentialGroup()
                .addGroup(ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ContactDetailsLayout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addGroup(ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ContactDetailsLayout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addGroup(ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(ContactDetailsLayout.createSequentialGroup()
                                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtConfirmEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(chkNoEmail))
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)))))
                    .addGroup(ContactDetailsLayout.createSequentialGroup()
                        .addGap(262, 262, 262)
                        .addComponent(jLabel5))
                    .addGroup(ContactDetailsLayout.createSequentialGroup()
                        .addGap(273, 273, 273)
                        .addComponent(jLabel1)))
                .addContainerGap(88, Short.MAX_VALUE))
        );
        ContactDetailsLayout.setVerticalGroup(
            ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContactDetailsLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ContactDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtContactNumber))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtConfirmEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(chkNoEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel5)
                .addGap(8, 8, 8)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(30, 105, 75));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Review your booking details before proceeding to payment");

        pnlPassengerSummary.setPreferredSize(new java.awt.Dimension(200, 429));

        javax.swing.GroupLayout pnlPassengerSummaryLayout = new javax.swing.GroupLayout(pnlPassengerSummary);
        pnlPassengerSummary.setLayout(pnlPassengerSummaryLayout);
        pnlPassengerSummaryLayout.setHorizontalGroup(
            pnlPassengerSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlPassengerSummaryLayout.setVerticalGroup(
            pnlPassengerSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 429, Short.MAX_VALUE)
        );

        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnBack.setForeground(new java.awt.Color(30, 105, 75));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        btnNext.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnNext.setForeground(new java.awt.Color(30, 105, 75));
        btnNext.setText("NEXT");
        btnNext.addActionListener(this::btnNextActionPerformed);

        btnPassengerDetails.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPassengerDetails.setForeground(new java.awt.Color(30, 105, 75));
        btnPassengerDetails.setText("PASSENGER DETAILS                                     ▼");
        btnPassengerDetails.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPassengerDetails.addActionListener(this::btnPassengerDetailsActionPerformed);

        lblMessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("BOOKING SUMMARY");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnPassengerDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlPassengerSummary, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(158, 158, 158)
                        .addComponent(btnBack)
                        .addGap(18, 18, 18)
                        .addComponent(btnNext)
                        .addGap(83, 83, 83))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(161, 161, 161))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(138, 138, 138))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(52, 52, 52)
                .addComponent(btnPassengerDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlPassengerSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnBack)
                        .addComponent(btnNext)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ContactDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 877, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ContactDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 69, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chkNoEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkNoEmailActionPerformed
 if (chkNoEmail.isSelected()) {

        txtEmail.setText("");
        txtConfirmEmail.setText("");

        txtEmail.setEnabled(false);
        txtConfirmEmail.setEnabled(false);


    } else {

        txtEmail.setEnabled(true);
        txtConfirmEmail.setEnabled(true);

}    }//GEN-LAST:event_chkNoEmailActionPerformed

    private void txtConfirmEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConfirmEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConfirmEmailActionPerformed

    private void txtContactNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContactNumberActionPerformed
            // TODO add your handling code here:
    }//GEN-LAST:event_txtContactNumberActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed

    for (int i = 0; i < firstNames.size(); i++) {

        String first = firstNames.get(i).getText();
        String last = lastNames.get(i).getText();

        if (sameName(first, last, i)) {

            JOptionPane.showMessageDialog(this,
                    "Passenger names cannot be the same.");

            return;
        }
    }

    if (!chkNoEmail.isSelected()) {

        if (txtEmail.getText().isEmpty()
                || txtConfirmEmail.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Please fill in all required fields.");

            return;
        }

        if (!txtEmail.getText().equals(txtConfirmEmail.getText())) {

            JOptionPane.showMessageDialog(this,
                    "Email addresses do not match.");

            return;
        }
    }
 

    PaymentFrame payment = new PaymentFrame();
    payment.contactNumber = txtContactNumber.getText().trim();
    payment.email = chkNoEmail.isSelected() ? "" : txtEmail.getText().trim();

    for (int i = 0; i < firstNames.size(); i++) {

        String name =
                firstNames.get(i).getText()
                + " "
                + lastNames.get(i).getText();

        payment.passengerNames.add(name);

        payment.seats.add(
                SeatManager.selectedSeats.get(i)
        );
        payment.firstNames.add(firstNames.get(i).getText().trim());
        payment.lastNames.add(lastNames.get(i).getText().trim());
     }

    payment.from = from;
    payment.to = to;
    payment.travelDate = travelDate;
    payment.tripTime = tripTime;
    payment.pickupTime = pickupTime;
    payment.tripCode = tripCode;
    payment.busType = busType;

    payment.farePerSeat = farePerSeat;

    payment.selectedSeatCount =
            SeatManager.selectedSeats.size();

    payment.totalFare =
            farePerSeat * payment.selectedSeatCount;

    payment.loadPassengerDetails();
    payment.loadPaymentDetails();

    payment.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnNextActionPerformed

                                              

    private void btnPassengerDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPassengerDetailsActionPerformed
        if (btnPassengerDetails.isSelected()) {
            pnlPassengerSummary.setVisible(true);
            btnPassengerDetails.setText("Passenger Details ▲");
        } else {
            pnlPassengerSummary.setVisible(false);
            btnPassengerDetails.setText("Passenger Details ▼");
        }
    }//GEN-LAST:event_btnPassengerDetailsActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
     ShowButtonFrame showButton = new ShowButtonFrame();

    showButton.from = from;
    showButton.to = to;
    showButton.travelDate = travelDate;
    showButton.tripTime = pickupTime;
    showButton.pickupTime = pickupTime;
    showButton.tripCode = tripCode;

    showButton.loadRoute();
    showButton.setVisible(true);

    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PassengerDetailsFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ContactDetails;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnNext;
    private javax.swing.JToggleButton btnPassengerDetails;
    private javax.swing.JCheckBox chkNoEmail;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JPanel pnlPassengerSummary;
    private javax.swing.JTextField txtConfirmEmail;
    private javax.swing.JTextField txtContactNumber;
    private javax.swing.JTextField txtEmail;
    // End of variables declaration//GEN-END:variables
}
