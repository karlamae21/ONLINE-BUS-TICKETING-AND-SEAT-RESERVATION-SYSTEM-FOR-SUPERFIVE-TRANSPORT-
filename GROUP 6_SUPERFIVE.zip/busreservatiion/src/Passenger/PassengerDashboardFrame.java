package Passenger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;
import LoginRegister.SuperFiveFrame;
import java.time.LocalTime;
public class PassengerDashboardFrame extends javax.swing.JFrame {
    
    
    int availableSeats1 = 44;
    int availableSeats2 = 44;
    int availableSeats3 = 44;
     int availableSeats4 = 44;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PassengerDashboardFrame.class.getName());

    Database.Trip[] trips = new Database.Trip[4];
    
    public PassengerDashboardFrame() {
    initComponents();

    pnlManageMenu.setVisible(false);
    pnlTrips.setVisible(true);
    pnltrip.setVisible(false);

       // Responsive main layout
    getContentPane().setLayout(new java.awt.BorderLayout());
    getContentPane().add(jScrollPane2, java.awt.BorderLayout.CENTER);

    // Allow scrolling without changing the trip panel design
    jScrollPane2.setVerticalScrollBarPolicy(
        javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    jScrollPane2.setHorizontalScrollBarPolicy(
        javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    jScrollPane2.getVerticalScrollBar().setUnitIncrement(20);
    jScrollPane2.getHorizontalScrollBar().setUnitIncrement(20);

    setMinimumSize(new java.awt.Dimension(900, 600));
    setSize(1200, 750);
    setLocationRelativeTo(null);

    setDateButtons();
}
    private int getFare(String from, String to) {

    if ((from.equals("CDO") && to.equals("Wao")) ||
        (from.equals("Wao") && to.equals("CDO"))) {
        return 350;
    }

    if ((from.equals("CDO") && to.equals("Dipolog")) ||
        (from.equals("Dipolog") && to.equals("CDO"))) {
        return 550;
    }

    if ((from.equals("CDO") && to.equals("Pagadian")) ||
        (from.equals("Pagadian") && to.equals("CDO"))) {
        return 450;
    }

    if ((from.equals("CDO") && to.equals("Maramag")) ||
        (from.equals("Maramag") && to.equals("CDO"))) {
        return 300;
    }

    if ((from.equals("CDO") && to.equals("Tubod")) ||
        (from.equals("Tubod") && to.equals("CDO"))) {
        return 400;
    }

    if ((from.equals("CDO") && to.equals("Kibawe")) ||
        (from.equals("Kibawe") && to.equals("CDO"))) {
        return 350;
    }

    if ((from.equals("CDO") && to.equals("Ozamiz")) ||
        (from.equals("Ozamiz") && to.equals("CDO"))) {
        return 500;
    }

    return 0;
}
    
    private boolean isPastTrip(Database.Trip trip, String date) {

    LocalDate travelDate = LocalDate.parse(
            date,
            DateTimeFormatter.ofPattern("MM/dd/yyyy")
    );

    if (travelDate.isBefore(LocalDate.now())) {
        return true;
    }

    if (travelDate.isAfter(LocalDate.now())) {
        return false;
    }

    LocalTime tripTime = LocalTime.parse(
            trip.time.toUpperCase(),
            DateTimeFormatter.ofPattern("h:mm a",
                    java.util.Locale.ENGLISH)
    );

    return !tripTime.isAfter(LocalTime.now());
}
    
private void setDateButtons() {

    LocalDate today = LocalDate.now();

    DateTimeFormatter format =
            DateTimeFormatter.ofPattern("EEE, dd MMM");

    btnDate1.setText(today.format(format));
    btnDate2.setText(today.plusDays(1).format(format));
    btnDate3.setText(today.plusDays(2).format(format));
    btnDate4.setText(today.plusDays(3).format(format));
    btnDate5.setText(today.plusDays(4).format(format));
    btnDate6.setText(today.plusDays(5).format(format));
    btnDate7.setText(today.plusDays(6).format(format));
    btnDate8.setText(today.plusDays(7).format(format));

    btnDate1.setBackground(java.awt.Color.WHITE);
    btnDate2.setBackground(java.awt.Color.WHITE);
    btnDate3.setBackground(java.awt.Color.WHITE);
    btnDate4.setBackground(java.awt.Color.WHITE);
    btnDate5.setBackground(java.awt.Color.WHITE);
    btnDate6.setBackground(java.awt.Color.WHITE);
    btnDate7.setBackground(java.awt.Color.WHITE);
    btnDate8.setBackground(java.awt.Color.WHITE);
}

private void selectDate(int days) {

    LocalDate date = LocalDate.now().plusDays(days);

    DateTimeFormatter format =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    txtTravelDate.setText(date.format(format));

    btnDate1.setBackground(java.awt.Color.WHITE);
    btnDate2.setBackground(java.awt.Color.WHITE);
    btnDate3.setBackground(java.awt.Color.WHITE);
    btnDate4.setBackground(java.awt.Color.WHITE);
    btnDate5.setBackground(java.awt.Color.WHITE);
    btnDate6.setBackground(java.awt.Color.WHITE);
    btnDate7.setBackground(java.awt.Color.WHITE);
    btnDate8.setBackground(java.awt.Color.WHITE);

    if (days == 0) btnDate1.setBackground(java.awt.Color.BLUE);
    if (days == 1) btnDate2.setBackground(java.awt.Color.BLUE);
    if (days == 2) btnDate3.setBackground(java.awt.Color.BLUE);
    if (days == 3) btnDate4.setBackground(java.awt.Color.BLUE);
    if (days == 4) btnDate5.setBackground(java.awt.Color.BLUE);
    if (days == 5) btnDate6.setBackground(java.awt.Color.BLUE);
    if (days == 6) btnDate7.setBackground(java.awt.Color.BLUE);
    if (days == 7) btnDate8.setBackground(java.awt.Color.BLUE);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        jPopupMenu3 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jPopupMenu4 = new javax.swing.JPopupMenu();
        jPanel4 = new javax.swing.JPanel();
        jButton38 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pnlTrips = new javax.swing.JPanel();
        pnldates = new javax.swing.JPanel();
        btnPrevious = new javax.swing.JButton();
        btnDate1 = new javax.swing.JButton();
        btnDate2 = new javax.swing.JButton();
        btnDate3 = new javax.swing.JButton();
        btnDate4 = new javax.swing.JButton();
        btnDate5 = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnDate6 = new javax.swing.JButton();
        btnDate7 = new javax.swing.JButton();
        btnDate8 = new javax.swing.JButton();
        chkHideFull1 = new javax.swing.JCheckBox();
        pnltrip = new javax.swing.JPanel();
        pnlTrip1 = new javax.swing.JPanel();
        lblTo1 = new javax.swing.JLabel();
        lblBus1 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        lblArrow1 = new javax.swing.JLabel();
        lblFrom1 = new javax.swing.JLabel();
        lblFare1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        lblBusType1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        TripCode1 = new javax.swing.JLabel();
        btnShowSeats1 = new javax.swing.JButton();
        pnlTrip2 = new javax.swing.JPanel();
        lblto2 = new javax.swing.JLabel();
        lblBus2 = new javax.swing.JLabel();
        lblFrom2 = new javax.swing.JLabel();
        lblArrow2 = new javax.swing.JLabel();
        lblfrom2 = new javax.swing.JLabel();
        lblFare2 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        lblBusType2 = new javax.swing.JLabel();
        btnShowSeats2 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        lblTripCode2 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        pnlTrip3 = new javax.swing.JPanel();
        lblTo3 = new javax.swing.JLabel();
        lblBus3 = new javax.swing.JLabel();
        lblTime3 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        lblFrom3 = new javax.swing.JLabel();
        lblFare3 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel44 = new javax.swing.JLabel();
        btnShowSeats3 = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        pnlTrip4 = new javax.swing.JPanel();
        lblTo4 = new javax.swing.JLabel();
        lblBus4 = new javax.swing.JLabel();
        lblTime4 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        lblFrom4 = new javax.swing.JLabel();
        lblFare4 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        lblBusType4 = new javax.swing.JLabel();
        btnShowSeats4 = new javax.swing.JButton();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        lblTripCode4 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        pnlTop = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbFrom = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cmbTo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtTravelDate = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnExchange = new javax.swing.JButton();
        btnDate = new javax.swing.JButton();
        pnlBottom = new javax.swing.JPanel();
        pnlStepbyStep = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        pnlManageMenu = new javax.swing.JPanel();
        btnLogOut = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        btnViewProfile = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jButton38.setText("1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane2.setPreferredSize(new java.awt.Dimension(1500, 1500));

        pnlTrips.setBackground(new java.awt.Color(250, 248, 227));
        pnlTrips.setForeground(new java.awt.Color(30, 105, 75));
        pnlTrips.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPrevious.setBackground(new java.awt.Color(30, 105, 75));
        btnPrevious.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPrevious.setForeground(new java.awt.Color(255, 255, 255));
        btnPrevious.setText("<");

        btnDate1.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate1.setText("Wed,  28 Sep");
        btnDate1.addActionListener(this::btnDate1ActionPerformed);

        btnDate2.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate2.setText("Thu, 29 Sep");
        btnDate2.addActionListener(this::btnDate2ActionPerformed);

        btnDate3.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate3.setText("Fri, 25 Sep");
        btnDate3.addActionListener(this::btnDate3ActionPerformed);

        btnDate4.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate4.setText("Sat, 26 Sep");
        btnDate4.addActionListener(this::btnDate4ActionPerformed);

        btnDate5.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate5.setText("Sun, 27 Sep");
        btnDate5.addActionListener(this::btnDate5ActionPerformed);

        btnNext.setBackground(new java.awt.Color(30, 105, 75));
        btnNext.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnNext.setForeground(new java.awt.Color(255, 255, 255));
        btnNext.setText(">");

        btnDate6.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate6.setText("Sun, 27 Sep");
        btnDate6.addActionListener(this::btnDate6ActionPerformed);

        btnDate7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate7.setText("Sun, 27 Sep");
        btnDate7.addActionListener(this::btnDate7ActionPerformed);

        btnDate8.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnDate8.setText("Mon, 28 Sep");
        btnDate8.addActionListener(this::btnDate8ActionPerformed);

        javax.swing.GroupLayout pnldatesLayout = new javax.swing.GroupLayout(pnldates);
        pnldates.setLayout(pnldatesLayout);
        pnldatesLayout.setHorizontalGroup(
            pnldatesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldatesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate6, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDate7, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDate8, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        pnldatesLayout.setVerticalGroup(
            pnldatesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldatesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnldatesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(btnDate1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDate8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNext, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pnlTrips.add(pnldates, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, 1039, -1));

        chkHideFull1.setText(" Hide Fully-Booked Trips");
        chkHideFull1.addActionListener(this::chkHideFull1ActionPerformed);
        pnlTrips.add(chkHideFull1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 340, -1, -1));

        pnltrip.setBackground(new java.awt.Color(30, 105, 75));

        pnlTrip1.setBackground(new java.awt.Color(255, 255, 255));

        lblTo1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTo1.setText("WAO");

        lblBus1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblBus1.setText("SUPER FIVE");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel21.setText("8:00 AM");

        lblArrow1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblArrow1.setText("→");

        lblFrom1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFrom1.setText("CDO");

        lblFare1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFare1.setText("PHP 350");

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        lblBusType1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBusType1.setText("Bus Type");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Regular AC");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setText("44 LEFT");

        jLabel27.setText("SF1");

        TripCode1.setText("Trip Code");

        btnShowSeats1.setBackground(new java.awt.Color(30, 105, 75));
        btnShowSeats1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowSeats1.setForeground(new java.awt.Color(255, 255, 255));
        btnShowSeats1.setText("SHOW SEATS");
        btnShowSeats1.addActionListener(this::btnShowSeats1ActionPerformed);

        javax.swing.GroupLayout pnlTrip1Layout = new javax.swing.GroupLayout(pnlTrip1);
        pnlTrip1.setLayout(pnlTrip1Layout);
        pnlTrip1Layout.setHorizontalGroup(
            pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblBus1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(lblFrom1, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblArrow1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(lblTo1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(lblFare1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(pnlTrip1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator2)
                .addContainerGap())
            .addGroup(pnlTrip1Layout.createSequentialGroup()
                .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblBusType1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlTrip1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(TripCode1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(161, 161, 161)
                .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(93, 93, 93)
                .addComponent(btnShowSeats1)
                .addGap(36, 36, 36))
        );
        pnlTrip1Layout.setVerticalGroup(
            pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFare1)
                    .addComponent(lblTo1)
                    .addComponent(lblArrow1)
                    .addComponent(lblFrom1)
                    .addComponent(jLabel21)
                    .addComponent(lblBus1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip1Layout.createSequentialGroup()
                        .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBusType1)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(TripCode1)))
                    .addGroup(pnlTrip1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel26)
                        .addComponent(btnShowSeats1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pnlTrip2.setBackground(new java.awt.Color(255, 255, 255));

        lblto2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblto2.setText("WAO");

        lblBus2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblBus2.setText("SUPER FIVE");

        lblFrom2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFrom2.setText("10:00 AM");

        lblArrow2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblArrow2.setText("→");

        lblfrom2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblfrom2.setText("CDO");

        lblFare2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFare2.setText("PHP 350");

        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));

        lblBusType2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBusType2.setText("Bus Type");

        btnShowSeats2.setBackground(new java.awt.Color(30, 105, 75));
        btnShowSeats2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowSeats2.setForeground(new java.awt.Color(255, 255, 255));
        btnShowSeats2.setText("SHOW SEATS");
        btnShowSeats2.addActionListener(this::btnShowSeats2ActionPerformed);

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel35.setText("Regular AC");

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel36.setText("44 LEFT");

        lblTripCode2.setText("Trip Code");

        jLabel59.setText("SF2");

        javax.swing.GroupLayout pnlTrip2Layout = new javax.swing.GroupLayout(pnlTrip2);
        pnlTrip2.setLayout(pnlTrip2Layout);
        pnlTrip2Layout.setHorizontalGroup(
            pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblBus2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91)
                .addComponent(lblFrom2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(lblfrom2, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(lblArrow2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(lblto2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblFare2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlTrip2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator5)
                .addContainerGap())
            .addGroup(pnlTrip2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBusType2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTripCode2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(161, 161, 161)
                .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip2Layout.createSequentialGroup()
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(92, 92, 92))
                    .addGroup(pnlTrip2Layout.createSequentialGroup()
                        .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(btnShowSeats2)
                .addGap(37, 37, 37))
        );
        pnlTrip2Layout.setVerticalGroup(
            pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFare2)
                    .addComponent(lblto2)
                    .addComponent(lblArrow2)
                    .addComponent(lblfrom2)
                    .addComponent(lblFrom2)
                    .addComponent(lblBus2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip2Layout.createSequentialGroup()
                        .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBusType2)
                            .addComponent(jLabel35))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTripCode2)
                            .addComponent(jLabel59)))
                    .addGroup(pnlTrip2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnShowSeats2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel36)))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pnlTrip3.setBackground(new java.awt.Color(255, 255, 255));

        lblTo3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTo3.setText("WAO");

        lblBus3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblBus3.setText("SUPER FIVE");

        lblTime3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTime3.setText("1:00 PM");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel41.setText("→");

        lblFrom3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFrom3.setText("CDO");

        lblFare3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFare3.setText("PHP 350");

        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel44.setText("Bus Type");

        btnShowSeats3.setBackground(new java.awt.Color(30, 105, 75));
        btnShowSeats3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowSeats3.setForeground(new java.awt.Color(255, 255, 255));
        btnShowSeats3.setText("SHOW SEATS");
        btnShowSeats3.addActionListener(this::btnShowSeats3ActionPerformed);

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel45.setText("Regular AC");

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel56.setText("44 LEFT");

        jLabel57.setText("Trip Code");

        jLabel60.setText("SF3");

        javax.swing.GroupLayout pnlTrip3Layout = new javax.swing.GroupLayout(pnlTrip3);
        pnlTrip3.setLayout(pnlTrip3Layout);
        pnlTrip3Layout.setHorizontalGroup(
            pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblBus3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(lblTime3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblFrom3, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblTo3, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(lblFare3, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(pnlTrip3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator6)
                .addContainerGap())
            .addGroup(pnlTrip3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(161, 161, 161)
                .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip3Layout.createSequentialGroup()
                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(94, 94, 94))
                    .addGroup(pnlTrip3Layout.createSequentialGroup()
                        .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(btnShowSeats3)
                .addGap(35, 35, 35))
        );
        pnlTrip3Layout.setVerticalGroup(
            pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFare3)
                    .addComponent(lblTo3)
                    .addComponent(jLabel41)
                    .addComponent(lblFrom3)
                    .addComponent(lblTime3)
                    .addComponent(lblBus3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip3Layout.createSequentialGroup()
                        .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel44)
                            .addComponent(jLabel45))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel57)
                            .addComponent(jLabel60)))
                    .addGroup(pnlTrip3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnShowSeats3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel56)))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pnlTrip4.setBackground(new java.awt.Color(255, 255, 255));

        lblTo4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTo4.setText("WAO");

        lblBus4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblBus4.setText("SUPER FIVE");

        lblTime4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTime4.setText("4:00 PM");

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel49.setText("→");

        lblFrom4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFrom4.setText("CDO");

        lblFare4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblFare4.setText("PHP 350");

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));

        lblBusType4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBusType4.setText("Bus Type");

        btnShowSeats4.setBackground(new java.awt.Color(30, 105, 75));
        btnShowSeats4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowSeats4.setForeground(new java.awt.Color(255, 255, 255));
        btnShowSeats4.setText("SHOW SEATS");
        btnShowSeats4.addActionListener(this::btnShowSeats4ActionPerformed);

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel53.setText("Regular AC");

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel54.setText("44 LEFT");

        lblTripCode4.setText("Trip Code");

        jLabel61.setText("SF4");

        javax.swing.GroupLayout pnlTrip4Layout = new javax.swing.GroupLayout(pnlTrip4);
        pnlTrip4.setLayout(pnlTrip4Layout);
        pnlTrip4Layout.setHorizontalGroup(
            pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblBus4, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(lblTime4, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(lblFrom4, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lblTo4, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(lblFare4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(pnlTrip4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator4)
                .addContainerGap())
            .addGroup(pnlTrip4Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBusType4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTripCode4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(161, 161, 161)
                .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip4Layout.createSequentialGroup()
                        .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95))
                    .addGroup(pnlTrip4Layout.createSequentialGroup()
                        .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(btnShowSeats4)
                .addGap(34, 34, 34))
        );
        pnlTrip4Layout.setVerticalGroup(
            pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTrip4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFare4)
                    .addComponent(lblTo4)
                    .addComponent(jLabel49)
                    .addComponent(lblFrom4)
                    .addComponent(lblTime4)
                    .addComponent(lblBus4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTrip4Layout.createSequentialGroup()
                        .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBusType4)
                            .addComponent(jLabel53))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTripCode4)
                            .addComponent(jLabel61)))
                    .addGroup(pnlTrip4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnShowSeats4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel54)))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnltripLayout = new javax.swing.GroupLayout(pnltrip);
        pnltrip.setLayout(pnltripLayout);
        pnltripLayout.setHorizontalGroup(
            pnltripLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnltripLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnltripLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlTrip2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTrip3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTrip4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTrip1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnltripLayout.setVerticalGroup(
            pnltripLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnltripLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlTrip1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTrip2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTrip3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTrip4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(531, 531, 531))
        );

        pnlTrips.add(pnltrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 480, 1040, 520));

        pnlTop.setBackground(new java.awt.Color(250, 248, 227));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Travel Easy  |  Book Bus Tickets Online with Superfive Bus");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Check schedules, fares & routes, and book bus tickets hassle-free across the Northern Mindanao. ");

        cmbFrom.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbFrom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO" }));
        cmbFrom.addActionListener(this::cmbFromActionPerformed);

        jLabel3.setText("FROM");

        cmbTo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbTo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz" }));
        cmbTo.addActionListener(this::cmbToActionPerformed);

        jLabel4.setText("TO");

        txtTravelDate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtTravelDate.addActionListener(this::txtTravelDateActionPerformed);

        btnSearch.setBackground(new java.awt.Color(30, 105, 75));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);

        jLabel5.setText("TRAVEL DATE");

        btnExchange.setText("⇄");
        btnExchange.addActionListener(this::btnExchangeActionPerformed);

        btnDate.setForeground(new java.awt.Color(30, 105, 75));
        btnDate.setText("📅");
        btnDate.addActionListener(this::btnDateActionPerformed);

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTopLayout.createSequentialGroup()
                        .addGap(174, 174, 174)
                        .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTopLayout.createSequentialGroup()
                                .addComponent(cmbFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnExchange, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbTo, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTopLayout.createSequentialGroup()
                                .addComponent(txtTravelDate, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 224, Short.MAX_VALUE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(pnlTopLayout.createSequentialGroup()
                        .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTopLayout.createSequentialGroup()
                                .addGap(409, 409, 409)
                                .addComponent(jLabel2))
                            .addGroup(pnlTopLayout.createSequentialGroup()
                                .addGap(227, 227, 227)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 981, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTravelDate, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbTo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExchange, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32))
        );

        pnlTrips.add(pnlTop, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1551, 200));

        pnlBottom.setBackground(new java.awt.Color(30, 105, 75));

        javax.swing.GroupLayout pnlBottomLayout = new javax.swing.GroupLayout(pnlBottom);
        pnlBottom.setLayout(pnlBottomLayout);
        pnlBottomLayout.setHorizontalGroup(
            pnlBottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1630, Short.MAX_VALUE)
        );
        pnlBottomLayout.setVerticalGroup(
            pnlBottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );

        pnlTrips.add(pnlBottom, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1017, 1630, 70));

        pnlStepbyStep.setBackground(new java.awt.Color(30, 105, 75));

        jButton3.setBackground(new java.awt.Color(250, 248, 237));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(30, 105, 75));
        jButton3.setText("CONTACT US");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        pnlManageMenu.setLayout(new java.awt.GridBagLayout());

        btnLogOut.setBackground(new java.awt.Color(250, 248, 237));
        btnLogOut.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogOut.setForeground(new java.awt.Color(30, 105, 75));
        btnLogOut.setText("LOGOUT");
        btnLogOut.addActionListener(this::btnLogOutActionPerformed);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Passenger/images/bobords.png"))); // NOI18N

        btnViewProfile.setBackground(new java.awt.Color(250, 248, 237));
        btnViewProfile.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnViewProfile.setForeground(new java.awt.Color(30, 105, 75));
        btnViewProfile.setText("VIEW PROFILE");
        btnViewProfile.addActionListener(this::btnViewProfileActionPerformed);

        javax.swing.GroupLayout pnlStepbyStepLayout = new javax.swing.GroupLayout(pnlStepbyStep);
        pnlStepbyStep.setLayout(pnlStepbyStepLayout);
        pnlStepbyStepLayout.setHorizontalGroup(
            pnlStepbyStepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStepbyStepLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 889, Short.MAX_VALUE)
                .addComponent(btnViewProfile)
                .addGap(18, 18, 18)
                .addGroup(pnlStepbyStepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlStepbyStepLayout.createSequentialGroup()
                        .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(120, 120, 120))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlStepbyStepLayout.createSequentialGroup()
                        .addComponent(pnlManageMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addComponent(jButton3)
                        .addGap(237, 237, 237))))
        );
        pnlStepbyStepLayout.setVerticalGroup(
            pnlStepbyStepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStepbyStepLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pnlStepbyStepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(btnLogOut)
                    .addComponent(btnViewProfile))
                .addGap(45, 45, 45)
                .addComponent(pnlManageMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pnlTrips.add(pnlStepbyStep, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1551, 110));

        jSeparator1.setForeground(new java.awt.Color(30, 105, 75));
        pnlTrips.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 1467, 10));

        jScrollPane2.setViewportView(pnlTrips);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1093, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTravelDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTravelDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTravelDateActionPerformed

    // Ibutang ang detalye sa usa ka biyahe sa panel niini
    private void showTrip(int index, String from, String to,
            javax.swing.JLabel lblFrom, javax.swing.JLabel lblTo, javax.swing.JLabel lblTime,
            javax.swing.JLabel lblFare, javax.swing.JLabel lblLeft, javax.swing.JLabel lblCode,
            javax.swing.JPanel panel) {

        Database.Trip t = trips[index];

        if (t == null) {
            panel.setVisible(false);
            return;
        }

        lblFrom.setText(from);
        lblTo.setText(to);
        lblTime.setText(t.time);
        lblFare.setText("PHP " + t.fare);
        lblLeft.setText(t.seatsLeft + " LEFT");
        lblCode.setText(t.tripCode);
        panel.setVisible(true);
    }

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();
    String date = txtTravelDate.getText().trim();

    if (date.isEmpty()) {
        pnltrip.setVisible(false);
        JOptionPane.showMessageDialog(this,
                "Please select a travel date.");
        return;
    }

    LocalDate selectedDate;

    try {
        selectedDate = LocalDate.parse(
                date,
                DateTimeFormatter.ofPattern("MM/dd/yyyy")
        );
    } catch (DateTimeParseException e) {
        pnltrip.setVisible(false);
        JOptionPane.showMessageDialog(this,
                "Invalid date. Please use MM/dd/yyyy format.");
        return;
    }

    if (selectedDate.isBefore(LocalDate.now())) {
        pnltrip.setVisible(false);
        JOptionPane.showMessageDialog(this,
                "Past dates are not allowed. Please select today or a future date.");
        txtTravelDate.setText("");
        return;
    }

    Database.DatabaseSetup.createDatabase();

        java.util.ArrayList<Database.Trip> list =
        Database.ScheduleDB.getTrips(from, to, date);

list.removeIf(trip -> isPastTrip(trip, date));

    trips = new Database.Trip[4];

    for (int i = 0; i < 4 && i < list.size(); i++) {
        trips[i] = list.get(i);
    }
    if (list.isEmpty()) {
        pnltrip.setVisible(false);
        JOptionPane.showMessageDialog(this,
                "No schedule available for this route and date.");
        return;
    }

    showTrip(0, from, to, lblFrom1, lblTo1, jLabel21,
            lblFare1, jLabel26, jLabel27, pnlTrip1);

    showTrip(1, from, to, lblfrom2, lblto2, lblFrom2,
            lblFare2, jLabel36, jLabel59, pnlTrip2);

    showTrip(2, from, to, lblFrom3, lblTo3, lblTime3,
            lblFare3, jLabel56, jLabel60, pnlTrip3);

    showTrip(3, from, to, lblFrom4, lblTo4, lblTime4,
            lblFare4, jLabel54, jLabel61, pnlTrip4);

    availableSeats1 = trips[0] != null ? trips[0].seatsLeft : 0;
    availableSeats2 = trips[1] != null ? trips[1].seatsLeft : 0;
    availableSeats3 = trips[2] != null ? trips[2].seatsLeft : 0;
    availableSeats4 = trips[3] != null ? trips[3].seatsLeft : 0;

    chkHideFull1.setSelected(false);
    pnltrip.setVisible(true);

    }//GEN-LAST:event_btnSearchActionPerformed

    private void cmbFromActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFromActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFromActionPerformed

    private void btnExchangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExchangeActionPerformed

    String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();

    cmbFrom.setSelectedItem(to);
    cmbTo.setSelectedItem(from);
    }//GEN-LAST:event_btnExchangeActionPerformed

    private void cmbToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbToActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbToActionPerformed

    private void btnDate3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate3ActionPerformed
    selectDate(2);
    }//GEN-LAST:event_btnDate3ActionPerformed

    private void btnDate8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate8ActionPerformed
    selectDate(7);
    }//GEN-LAST:event_btnDate8ActionPerformed

    
    private void btnDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDateActionPerformed
       txtTravelDate.setText(
    new java.text.SimpleDateFormat("MM/dd/yyyy")
    .format(new java.util.Date()));
    }//GEN-LAST:event_btnDateActionPerformed

    private void btnShowSeats1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowSeats1ActionPerformed
    String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();

      ShowButtonFrame trip = new ShowButtonFrame();

    trip.from = from;
    trip.to = to;
    trip.travelDate = txtTravelDate.getText();
    if (trips[0] == null) {
        return;
    }
    trip.pickupTime = trips[0].time;
    trip.tripCode = trips[0].tripCode;
    SeatManager.scheduleId = trips[0].scheduleId;
    SeatManager.dbFare = trips[0].fare;

    trip.loadRoute();

    trip.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnShowSeats1ActionPerformed

    private void btnShowSeats2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowSeats2ActionPerformed
      String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();

    ShowButtonFrame trip = new ShowButtonFrame();
    trip.from = from;
    trip.to = to;
    trip.travelDate = txtTravelDate.getText();
    if (trips[1] == null) {
        return;
    }
    trip.pickupTime = trips[1].time;
    trip.tripCode = trips[1].tripCode;
    SeatManager.scheduleId = trips[1].scheduleId;
    SeatManager.dbFare = trips[1].fare;

    trip.loadRoute();

    trip.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnShowSeats2ActionPerformed

    private void btnShowSeats3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowSeats3ActionPerformed
    
    String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();
    
    ShowButtonFrame trip = new ShowButtonFrame();
    trip.from = from;
    trip.to = to;
    trip.travelDate = txtTravelDate.getText();
    if (trips[2] == null) {
        return;
    }
    trip.pickupTime = trips[2].time;
    trip.tripCode = trips[2].tripCode;
    SeatManager.scheduleId = trips[2].scheduleId;
    SeatManager.dbFare = trips[2].fare;

    trip.loadRoute();

    trip.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnShowSeats3ActionPerformed

    private void btnShowSeats4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowSeats4ActionPerformed
    
    String from = cmbFrom.getSelectedItem().toString();
    String to = cmbTo.getSelectedItem().toString();
    
    ShowButtonFrame trip = new ShowButtonFrame();
    trip.from = from;
    trip.to = to;
    trip.travelDate = txtTravelDate.getText();
    if (trips[3] == null) {
        return;
    }
    trip.pickupTime = trips[3].time;
    trip.tripCode = trips[3].tripCode;
    SeatManager.scheduleId = trips[3].scheduleId;
    SeatManager.dbFare = trips[3].fare;

    trip.loadRoute();

    trip.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnShowSeats4ActionPerformed

    private void btnDate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate1ActionPerformed
     selectDate(0);
    }//GEN-LAST:event_btnDate1ActionPerformed

    private void btnDate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate2ActionPerformed
    selectDate(1);
    }//GEN-LAST:event_btnDate2ActionPerformed

    private void btnDate4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate4ActionPerformed
    selectDate(3);
    }//GEN-LAST:event_btnDate4ActionPerformed

    private void btnDate5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate5ActionPerformed
    selectDate(4);
    }//GEN-LAST:event_btnDate5ActionPerformed

    private void btnDate6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate6ActionPerformed
    selectDate(5);
    }//GEN-LAST:event_btnDate6ActionPerformed

    private void btnDate7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate7ActionPerformed
    selectDate(6);
    }//GEN-LAST:event_btnDate7ActionPerformed

    private void chkHideFull1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkHideFull1ActionPerformed
    if (chkHideFull1.isSelected()) {

        if (availableSeats1 == 0) {
            pnlTrip1.setVisible(false);
        }

        if (availableSeats2 == 0) {
            pnlTrip2.setVisible(false);
        }

        if (availableSeats3 == 0) {
            pnlTrip3.setVisible(false);
        }
    if (availableSeats4 == 0) {
            pnlTrip4.setVisible(false);
        }
    } else {

        pnlTrip1.setVisible(trips[0] != null);
        pnlTrip2.setVisible(trips[1] != null);
        pnlTrip3.setVisible(trips[2] != null);
        pnlTrip4.setVisible(trips[3] != null);
    }
    }//GEN-LAST:event_chkHideFull1ActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
     SuperFiveFrame main = new SuperFiveFrame();
     main.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    ContactUsFrame contact = new ContactUsFrame();
    contact.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnViewProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewProfileActionPerformed
  ViewProfileFrame view = new ViewProfileFrame();
    view.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnViewProfileActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PassengerDashboardFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TripCode1;
    private javax.swing.JButton btnDate;
    private javax.swing.JButton btnDate1;
    private javax.swing.JButton btnDate2;
    private javax.swing.JButton btnDate3;
    private javax.swing.JButton btnDate4;
    private javax.swing.JButton btnDate5;
    private javax.swing.JButton btnDate6;
    private javax.swing.JButton btnDate7;
    private javax.swing.JButton btnDate8;
    private javax.swing.JButton btnExchange;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnShowSeats1;
    private javax.swing.JButton btnShowSeats2;
    private javax.swing.JButton btnShowSeats3;
    private javax.swing.JButton btnShowSeats4;
    private javax.swing.JButton btnViewProfile;
    private javax.swing.JCheckBox chkHideFull1;
    private javax.swing.JComboBox<String> cmbFrom;
    private javax.swing.JComboBox<String> cmbTo;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton38;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JPopupMenu jPopupMenu3;
    private javax.swing.JPopupMenu jPopupMenu4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JLabel lblArrow1;
    private javax.swing.JLabel lblArrow2;
    private javax.swing.JLabel lblBus1;
    private javax.swing.JLabel lblBus2;
    private javax.swing.JLabel lblBus3;
    private javax.swing.JLabel lblBus4;
    private javax.swing.JLabel lblBusType1;
    private javax.swing.JLabel lblBusType2;
    private javax.swing.JLabel lblBusType4;
    private javax.swing.JLabel lblFare1;
    private javax.swing.JLabel lblFare2;
    private javax.swing.JLabel lblFare3;
    private javax.swing.JLabel lblFare4;
    private javax.swing.JLabel lblFrom1;
    private javax.swing.JLabel lblFrom2;
    private javax.swing.JLabel lblFrom3;
    private javax.swing.JLabel lblFrom4;
    private javax.swing.JLabel lblTime3;
    private javax.swing.JLabel lblTime4;
    private javax.swing.JLabel lblTo1;
    private javax.swing.JLabel lblTo3;
    private javax.swing.JLabel lblTo4;
    private javax.swing.JLabel lblTripCode2;
    private javax.swing.JLabel lblTripCode4;
    private javax.swing.JLabel lblfrom2;
    private javax.swing.JLabel lblto2;
    private javax.swing.JPanel pnlBottom;
    private javax.swing.JPanel pnlManageMenu;
    private javax.swing.JPanel pnlStepbyStep;
    private javax.swing.JPanel pnlTop;
    private javax.swing.JPanel pnlTrip1;
    private javax.swing.JPanel pnlTrip2;
    private javax.swing.JPanel pnlTrip3;
    private javax.swing.JPanel pnlTrip4;
    private javax.swing.JPanel pnlTrips;
    private javax.swing.JPanel pnldates;
    private javax.swing.JPanel pnltrip;
    private javax.swing.JTextField txtTravelDate;
    // End of variables declaration//GEN-END:variables
}
