
package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ScheduleDB {

    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    // Convert "MM/dd/yyyy" to java.sql.Date
    public static java.sql.Date toSqlDate(String text) {
        return java.sql.Date.valueOf(
                LocalDate.parse(text.trim(), FORMAT)
        );
    }

    // Create a schedule and 44 seats. Return the schedule_id.
    public static int createSchedule(
            Connection con,
            String tripCode,
            String origin,
            String destination,
            String travelDate,
            String time,
            int fare) throws Exception {

        String digits = tripCode.replaceAll("[^0-9]", "");
        int num = digits.isEmpty() ? 0 : Integer.parseInt(digits);
        String busNo = "BUS-" + String.format("%02d", num);

        int scheduleId;

        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO schedule "
                + "(trip_code, bus_no, origin, destination, travel_date, departure_time, fare) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, tripCode);
            ps.setString(2, busNo);
            ps.setString(3, origin);
            ps.setString(4, destination);
            ps.setDate(5, toSqlDate(travelDate));
            ps.setString(6, time);
            ps.setInt(7, fare);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    scheduleId = keys.getInt(1);
                } else {
                    throw new Exception("Failed to get schedule ID.");
                }
            }
        }

        // Create 44 available seats for the schedule
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO seat "
                + "(schedule_id, seat_number, status) "
                + "VALUES (?, ?, 'AVAILABLE')")) {

            for (int seat = 1; seat <= 44; seat++) {
                ps.setInt(1, scheduleId);
                ps.setInt(2, seat);
                ps.addBatch();
            }

            ps.executeBatch();
        }

        return scheduleId;
    }

    // Find an existing schedule or create a new one
    public static int getOrCreateScheduleId(
            Connection con,
            String tripCode,
            String origin,
            String destination,
            String travelDate,
            String time,
            int fare) throws Exception {

        try (PreparedStatement ps = con.prepareStatement(
                "SELECT schedule_id FROM schedule "
                + "WHERE origin = ? AND destination = ? "
                + "AND travel_date = ? AND departure_time = ?")) {

            ps.setString(1, origin);
            ps.setString(2, destination);
            ps.setDate(3, toSqlDate(travelDate));
            ps.setString(4, time);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        return createSchedule(
                con, tripCode, origin, destination,
                travelDate, time, fare
        );
    }

    // Get booked seat numbers for a route, date, and time
    public static ArrayList<Integer> getBookedSeats(
            String origin,
            String destination,
            String travelDate,
            String time) {

        ArrayList<Integer> list = new ArrayList<>();

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT st.seat_number "
                     + "FROM seat st "
                     + "JOIN schedule s ON st.schedule_id = s.schedule_id "
                     + "WHERE s.origin = ? AND s.destination = ? "
                     + "AND s.travel_date = ? "
                     + "AND s.departure_time = ? "
                     + "AND st.status = 'BOOKED'")) {

            ps.setString(1, origin);
            ps.setString(2, destination);
            ps.setDate(3, toSqlDate(travelDate));
            ps.setString(4, time);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getInt(1));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Get available trips for the selected route and travel date
    public static ArrayList<Trip> getTrips(
            String origin,
            String destination,
            String travelDate) {

        ArrayList<Trip> trips = new ArrayList<>();

        String sql = "SELECT s.schedule_id, s.trip_code, s.bus_no, "
                + "s.departure_time, s.fare, "
                + "(SELECT COUNT(*) FROM seat "
                + "WHERE seat.schedule_id = s.schedule_id "
                + "AND seat.status = 'AVAILABLE') AS free_seats "
                + "FROM schedule s "
                + "WHERE ((s.origin = ? AND s.destination = ?) "
                + "OR (s.origin = ? AND s.destination = ?)) "
                + "AND s.travel_date = ? "
                + "ORDER BY STR_TO_DATE(s.departure_time, '%l:%i %p'), "
                + "s.schedule_id";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, origin);
            ps.setString(2, destination);
            ps.setString(3, destination);
            ps.setString(4, origin);
            ps.setDate(5, toSqlDate(travelDate));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Trip t = new Trip();

                    t.scheduleId = rs.getInt("schedule_id");
                    t.tripCode = rs.getString("trip_code");
                    t.busNo = rs.getString("bus_no");
                    t.time = rs.getString("departure_time");
                    t.fare = rs.getInt("fare");
                    t.seatsLeft = rs.getInt("free_seats");

                    trips.add(t);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return trips;
    }

    // Get booked seats using the schedule ID
    public static ArrayList<Integer> getBookedSeatsBySchedule(
            int scheduleId) {

        ArrayList<Integer> list = new ArrayList<>();

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT seat_number FROM seat "
                     + "WHERE schedule_id = ? AND status = 'BOOKED'")) {

            ps.setInt(1, scheduleId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getInt(1));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Get schedules for the admin table.
    // Show today's schedules only, with a maximum of 28 rows.
    // If from and to are provided, filter by the selected route.
    public static ArrayList<Object[]> getSchedules(
            String from,
            String to) {

        ArrayList<Object[]> rows = new ArrayList<>();

        String sql = "SELECT s.schedule_id, s.bus_no, "
                + "s.origin, s.destination, "
                + "DATE_FORMAT(s.travel_date, '%m/%d/%Y') AS tdate, "
                + "s.departure_time, s.fare, "
                + "(SELECT COUNT(*) FROM seat "
                + "WHERE seat.schedule_id = s.schedule_id "
                + "AND seat.status = 'AVAILABLE') AS free_seats "
                + "FROM schedule s "
                + "WHERE 1 = 1 ";
        
        // Filter by route if both locations are provided.
        // The route can match either direction.
      if (from != null && to != null) {
    sql += "AND ((s.origin = ? AND s.destination = ?) "
            + "OR (s.origin = ? AND s.destination = ?)) ";
    }

        // Sort the schedules and show no more than 28 rows.
        sql += "ORDER BY s.schedule_id ASC LIMIT 28";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Set the route parameters when filtering is enabled.
            if (from != null && to != null) {
                ps.setString(1, from);
                ps.setString(2, to);
                ps.setString(3, to);
                ps.setString(4, from);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{
                        rs.getInt("schedule_id"),
                        rs.getString("bus_no"),
                        rs.getString("origin"),
                        rs.getString("destination"),
                        rs.getString("tdate"),
                        rs.getString("departure_time"),
                        "PHP " + rs.getInt("fare"),
                        rs.getInt("free_seats")
                    });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows;
    }

    // Update an existing schedule.
    // If bookings exist, the route and date cannot be changed.
    // Return null if successful, or an error message if unsuccessful.
    public static String updateSchedule(
            int scheduleId,
            String busNo,
            String origin,
            String destination,
            String travelDate,
            String time,
            int fare) {

        try (Connection con = DbConnection.getConnection()) {

            // Check whether the schedule has bookings
            try (PreparedStatement check = con.prepareStatement(
                    "SELECT "
                    + "(SELECT COUNT(*) FROM booking "
                    + "WHERE schedule_id = ?) AS total, "
                    + "(origin = ? AND destination = ? "
                    + "AND travel_date = ?) AS same_trip "
                    + "FROM schedule WHERE schedule_id = ?")) {

                check.setInt(1, scheduleId);
                check.setString(2, origin);
                check.setString(3, destination);
                check.setDate(4, toSqlDate(travelDate));
                check.setInt(5, scheduleId);

                try (ResultSet rs = check.executeQuery()) {
                    if (!rs.next()) {
                        return "This schedule no longer exists.";
                    }

                    if (rs.getInt("total") > 0
                            && rs.getInt("same_trip") == 0) {
                        return "This schedule already has bookings. "
                                + "You can only change the bus, time and fare.";
                    }
                }
            }

            // Save the updated schedule details
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE schedule SET bus_no = ?, origin = ?, "
                    + "destination = ?, travel_date = ?, "
                    + "departure_time = ?, fare = ? "
                    + "WHERE schedule_id = ?")) {

                ps.setString(1, busNo);
                ps.setString(2, origin);
                ps.setString(3, destination);
                ps.setDate(4, toSqlDate(travelDate));
                ps.setString(5, time);
                ps.setInt(6, fare);
                ps.setInt(7, scheduleId);

                ps.executeUpdate();
            }

            return null;

        } catch (java.time.format.DateTimeParseException e) {
            return "Date must be in MM/dd/yyyy format.";

        } catch (Exception e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    // Delete a schedule if it has no bookings
    public static String deleteSchedule(int scheduleId) {

        try (Connection con = DbConnection.getConnection()) {

            // Check whether the schedule has bookings
            try (PreparedStatement check = con.prepareStatement(
                    "SELECT COUNT(*) FROM booking "
                    + "WHERE schedule_id = ?")) {

                check.setInt(1, scheduleId);

                try (ResultSet rs = check.executeQuery()) {
                    rs.next();

                    if (rs.getInt(1) > 0) {
                        return "This schedule already has bookings "
                                + "and cannot be removed.";
                    }
                }
            }

            // Delete the seats belonging to the schedule
            try (PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM seat WHERE schedule_id = ?")) {

                ps.setInt(1, scheduleId);
                ps.executeUpdate();
            }

            // Delete the schedule
            try (PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM schedule WHERE schedule_id = ?")) {

                ps.setInt(1, scheduleId);
                ps.executeUpdate();
            }

            return null;

        } catch (Exception e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }
}
